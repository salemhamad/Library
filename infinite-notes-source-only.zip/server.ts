import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json({ limit: "20mb" }));

// Initialize Gemini AI Client safely
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("مفتاح GEMINI_API_KEY غير متاح في بيئة التشغيل.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Health
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Summarization
app.post("/api/ai/summarize", async (req, res) => {
  try {
    const { content } = req.body;
    if (!content || typeof content !== "string") {
      return res.status(400).json({ error: "محتوى الملاحظة مطلوب." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `قم بتلخيص النص والملاحظة التالية بشكل احترافي، دقيق، ومنظم في نقاط رئيسية بلغة نص الملاحظة نفسها:\n\n${content}`,
    });

    res.json({ result: response.text || "تعذر إنشاء التلخيص." });
  } catch (error: any) {
    console.error("AI Summarize Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Rephrasing
app.post("/api/ai/rephrase", async (req, res) => {
  try {
    const { text, style } = req.body;
    if (!text) {
      return res.status(400).json({ error: "النص مطلوب للإعادة الصياغة." });
    }

    const stylePromptMap: Record<string, string> = {
      professional: "بأسلوب رسمي واحترافي ممتاز",
      concise: "بأسلوب مختصر، موجز، ومباشر دون حشو",
      expanded: "مع التوسع والشرح المفصل وإضافة تفاصيل توضيحية",
      simplified: "بأسلوب مبسط جداً وسهل الفهم",
      creative: "بأسلوب إبداعي وجذاب",
    };

    const targetStyle = stylePromptMap[style] || stylePromptMap.professional;

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `أعد صياغة النص التالي ${targetStyle}:\n\n${text}\n\nأرجع النص المعدل فقط دون تعليقات إضافية.`,
    });

    res.json({ result: response.text || text });
  } catch (error: any) {
    console.error("AI Rephrase Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Grammar & Spelling Fix
app.post("/api/ai/fix-grammar", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "النص مطلوب للتصحيح." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `قم بتصحيح كافة الأخطاء النحوية والإملائية والمطبعية في النص التالي مع الحفاظ على المعنى الأصلي كاملاً:\n\n${text}\n\nأرجع النص المصحح فقط.`,
    });

    res.json({ result: response.text || text });
  } catch (error: any) {
    console.error("AI Grammar Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Translation
app.post("/api/ai/translate", async (req, res) => {
  try {
    const { text, targetLang } = req.body;
    if (!text || !targetLang) {
      return res.status(400).json({ error: "النص ولغة الهدف مطلوبان." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `ترجم النص التالي بدقة واحترافية إلى اللغة (${targetLang}):\n\n${text}\n\nأرجع الترجمة فقط.`,
    });

    res.json({ result: response.text || text });
  } catch (error: any) {
    console.error("AI Translate Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Extract Tasks
app.post("/api/ai/extract-tasks", async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: "المحتوى مطلوب لاستخراج المهام." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `استخرج جميع المهام والإجراءات المطلوبة من الملاحظة التالية كقائمة مهام منظمة JSON:\n\n${content}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              text: { type: Type.STRING, description: "نص المهمة" },
              priority: { type: Type.STRING, description: "الأولوية: high, medium, low" },
            },
            required: ["text", "priority"],
          },
        },
      },
    });

    let tasks = [];
    if (response.text) {
      try {
        tasks = JSON.parse(response.text.trim());
      } catch (e) {
        console.error("Failed to parse JSON tasks:", e);
      }
    }

    res.json({ tasks });
  } catch (error: any) {
    console.error("AI Extract Tasks Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Suggest Titles
app.post("/api/ai/suggest-titles", async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ error: "المحتوى مطلوب لاقتراح العناوين." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `اقترح 5 عناوين قصيرة وجذابة ومناسبة جداً للملاحظة التالية:\n\n${content}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
      },
    });

    let titles: string[] = [];
    if (response.text) {
      try {
        titles = JSON.parse(response.text.trim());
      } catch (e) {
        console.error("Failed to parse JSON titles:", e);
      }
    }

    res.json({ titles });
  } catch (error: any) {
    console.error("AI Suggest Titles Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Generate Table
app.post("/api/ai/generate-table", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "وصف الجدول مطلوب." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `قم بإنشاء جدول HTML غني أو جدول Markdown منظم ينفذ الوصف التالي:\n\n${prompt}\n\nأرجع كود الجدول بتنسيق HTML نظيف ومناسب للعرض مباشرة في محرر الملاحظات.`,
    });

    res.json({ result: response.text || "" });
  } catch (error: any) {
    console.error("AI Generate Table Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// AI Q&A Chat with Note
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, noteContext } = req.body;
    if (!message) {
      return res.status(400).json({ error: "السؤال مطلوب." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `أنت مساعد ذكي متخصص في إدارة وتنسيق الملاحظات. إنسق مع المستخدم بناءً على سياق الملاحظة المرفق.\n\nسياق الملاحظة:\n${noteContext || "لا يوجد محتوى حالي"}\n\nسؤال المستخدم:\n${message}`,
    });

    res.json({ result: response.text || "لم يتم استلام رد من النموذج." });
  } catch (error: any) {
    console.error("AI Chat Error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب." });
  }
});

// Vite Middleware & Server Initialization
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
