import React, { useState } from 'react';
import { 
  ChevronRight, ChevronDown, Plus, Search, Folder, Star, Pin, Archive, 
  Trash2, Tag, Palette, MoreVertical, Copy, Move, RefreshCw, X, FileText,
  Filter, Sparkles, FolderPlus, Layers, CheckCircle2, SlidersHorizontal, Eye, ShieldCheck
} from 'lucide-react';
import { Note, NoteTreeNode, FilterType, FilterState, SortOption, TaskItem, AttachmentItem } from '../../types';
import { COLOR_PRESETS } from '../../services/storage';
import { NoteTasksManager } from '../Tasks/NoteTasksManager';
import { AttachmentsGallery } from '../Media/AttachmentsGallery';

interface NoteTreeSidebarProps {
  tree: NoteTreeNode[];
  allNotes: Note[];
  activeNoteId: string | null;
  activeNote?: Note | null;
  onUpdateTasks?: (tasks: TaskItem[]) => void;
  onUpdateAttachments?: (attachments: AttachmentItem[]) => void;
  onSelectNote: (id: string) => void;
  onCreateRootNote: () => void;
  onCreateSubNote: (parentId: string) => void;
  onRenameNote: (id: string, newTitle: string) => void;
  onDuplicateNote: (id: string) => void;
  onMoveNoteClick: (id: string) => void;
  onTogglePin: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onToggleArchive: (id: string) => void;
  onDeleteNote: (id: string, permanent?: boolean) => void;
  onRestoreNote: (id: string) => void;
  onChangeColor: (id: string, color: string) => void;
  filterState: FilterState;
  onUpdateFilter: (updated: Partial<FilterState>) => void;
  allTags: string[];
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onOpenAdmin?: () => void;
}

export const NoteTreeSidebar: React.FC<NoteTreeSidebarProps> = ({
  tree,
  allNotes,
  activeNoteId,
  activeNote,
  onUpdateTasks,
  onUpdateAttachments,
  onSelectNote,
  onCreateRootNote,
  onCreateSubNote,
  onRenameNote,
  onDuplicateNote,
  onMoveNoteClick,
  onTogglePin,
  onToggleFavorite,
  onToggleArchive,
  onDeleteNote,
  onRestoreNote,
  onChangeColor,
  filterState,
  onUpdateFilter,
  allTags,
  isOpenMobile,
  onCloseMobile,
  onOpenAdmin,
}) => {
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({
    'note-root-1': true,
    'note-design-1': true,
    'note-coding-1': true,
  });

  const [contextMenuNoteId, setContextMenuNoteId] = useState<string | null>(null);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState<string>('');
  const [colorPickerNoteId, setColorPickerNoteId] = useState<string | null>(null);

  const toggleExpand = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleStartRename = (note: Note, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingNoteId(note.id);
    setEditingTitle(note.title);
    setContextMenuNoteId(null);
  };

  const handleSaveRename = (id: string) => {
    if (editingTitle.trim()) {
      onRenameNote(id, editingTitle.trim());
    }
    setEditingNoteId(null);
  };

  // Helper to render tree node recursively
  const renderTreeNode = (node: NoteTreeNode) => {
    const isSelected = activeNoteId === node.id;
    const isExpanded = expandedIds[node.id] || false;
    const hasChildren = node.children && node.children.length > 0;
    const isEditing = editingNoteId === node.id;

    const colorConfig = COLOR_PRESETS.find((c) => c.id === node.color) || COLOR_PRESETS[0];

    return (
      <div key={node.id} className="select-none my-0.5">
        <div
          onClick={() => onSelectNote(node.id)}
          className={`group relative flex items-center justify-between py-1.5 px-2 rounded-lg text-xs font-medium cursor-pointer transition-all duration-150 ${
            isSelected
              ? 'bg-blue-600 text-white shadow-xs font-semibold'
              : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80'
          }`}
          style={{ paddingRight: `${Math.min(node.depth * 14 + 8, 120)}px` }}
        >
          {/* Left info & toggle */}
          <div className="flex items-center gap-1.5 min-w-0 flex-1">
            {hasChildren ? (
              <button
                type="button"
                onClick={(e) => toggleExpand(node.id, e)}
                className={`p-0.5 rounded-xs hover:bg-black/10 dark:hover:bg-white/10 transition-colors shrink-0 ${
                  isSelected ? 'text-white' : 'text-slate-400 dark:text-slate-500'
                }`}
              >
                {isExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 rtl:rotate-180" />
                )}
              </button>
            ) : (
              <span className="w-4 h-4 shrink-0 inline-block" />
            )}

            {/* Note icon or color dot */}
            <span className="text-sm shrink-0">
              {node.icon || '📄'}
            </span>

            {/* Title inline edit or text */}
            {isEditing ? (
              <input
                type="text"
                value={editingTitle}
                onChange={(e) => setEditingTitle(e.target.value)}
                onBlur={() => handleSaveRename(node.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveRename(node.id);
                  if (e.key === 'Escape') setEditingNoteId(null);
                }}
                autoFocus
                onClick={(e) => e.stopPropagation()}
                className="w-full bg-white text-slate-900 dark:bg-slate-800 dark:text-slate-100 px-1.5 py-0.5 rounded-md border border-blue-400 focus:outline-hidden text-xs"
              />
            ) : (
              <span className="truncate flex-1 text-right" title={node.title}>
                {node.title || 'بدون عنوان'}
              </span>
            )}
          </div>

          {/* Right badges & Actions */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Color indicator dot if not default */}
            {node.color && node.color !== 'slate' && !isSelected && (
              <span
                className="w-2 h-2 rounded-full shrink-0"
                style={{ backgroundColor: colorConfig.hex }}
              />
            )}

            {/* Badges */}
            {node.isPinned && (
              <Pin className={`w-3 h-3 ${isSelected ? 'text-amber-200 fill-amber-200' : 'text-amber-500 fill-amber-500'}`} />
            )}
            {node.isFavorite && (
              <Star className={`w-3 h-3 ${isSelected ? 'text-rose-200 fill-rose-200' : 'text-rose-500 fill-rose-500'}`} />
            )}
            
            {node.childrenCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                isSelected ? 'bg-blue-700 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}>
                {node.childrenCount}
              </span>
            )}

            {/* Quick add sub-note button on hover */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onCreateSubNote(node.id);
                setExpandedIds((prev) => ({ ...prev, [node.id]: true }));
              }}
              className={`opacity-0 group-hover:opacity-100 p-1 rounded-md transition-opacity hover:bg-black/10 dark:hover:bg-white/10 ${
                isSelected ? 'text-white' : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
              }`}
              title="إضافة ملاحظة فرعية داخل هذه الملاحظة"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>

            {/* Menu button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setContextMenuNoteId(contextMenuNoteId === node.id ? null : node.id);
              }}
              className={`opacity-0 group-hover:opacity-100 p-1 rounded-md transition-opacity hover:bg-black/10 dark:hover:bg-white/10 ${
                isSelected ? 'text-white' : 'text-slate-500 hover:text-slate-800 dark:text-slate-400'
              }`}
              title="خيارات الملاحظة"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Context Menu Dropdown */}
          {contextMenuNoteId === node.id && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute left-2 top-full mt-1 z-30 w-48 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl py-1 text-slate-700 dark:text-slate-200 text-xs animate-in fade-in zoom-in-95 duration-100"
            >
              <button
                type="button"
                onClick={(e) => {
                  onCreateSubNote(node.id);
                  setExpandedIds((prev) => ({ ...prev, [node.id]: true }));
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-blue-500" />
                <span>إضافة ملاحظة فرعية</span>
              </button>

              <button
                type="button"
                onClick={(e) => handleStartRename(node, e)}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>إعادة تسمية</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onDuplicateNote(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-slate-500" />
                <span>تكرار الملاحظة والشجرة</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onMoveNoteClick(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Move className="w-3.5 h-3.5 text-slate-500" />
                <span>نقل لملاحظة أخرى</span>
              </button>

              <div className="my-1 border-t border-slate-200 dark:border-slate-700" />

              <button
                type="button"
                onClick={() => {
                  onTogglePin(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Pin className="w-3.5 h-3.5 text-amber-500" />
                <span>{node.isPinned ? 'إلغاء التثبيت' : 'تثبيت بالقمة'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onToggleFavorite(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Star className="w-3.5 h-3.5 text-rose-500" />
                <span>{node.isFavorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onToggleArchive(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-700/70 text-right cursor-pointer"
              >
                <Archive className="w-3.5 h-3.5 text-slate-500" />
                <span>{node.isArchived ? 'إلغاء الأرشفة' : 'أرشفة'}</span>
              </button>

              {/* Color sub-picker */}
              <div className="px-3 py-1.5 border-t border-slate-200 dark:border-slate-700">
                <span className="text-[10px] font-semibold text-slate-400 block mb-1">تصنيف بالألوان:</span>
                <div className="flex items-center gap-1.5">
                  {COLOR_PRESETS.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        onChangeColor(node.id, c.id);
                        setContextMenuNoteId(null);
                      }}
                      className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600 cursor-pointer hover:scale-110 transition-transform"
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>

              <div className="my-1 border-t border-slate-200 dark:border-slate-700" />

              <button
                type="button"
                onClick={() => {
                  onDeleteNote(node.id);
                  setContextMenuNoteId(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-right cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>نقل إلى سلة المهملات</span>
              </button>
            </div>
          )}
        </div>

        {/* Children Sub-Tree */}
        {hasChildren && isExpanded && (
          <div className="relative">
            {/* Tree branch guide line */}
            <div className="absolute right-3.5 top-0 bottom-2 w-px bg-slate-200 dark:bg-slate-800" />
            {node.children.map((child) => renderTreeNode(child))}
          </div>
        )}
      </div>
    );
  };

  const activeNotesCount = allNotes.filter((n) => !n.isDeleted).length;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      <aside
        className={`fixed md:static top-0 bottom-0 right-0 z-50 w-72 md:w-80 bg-slate-50 dark:bg-slate-900/95 border-l border-slate-200/80 dark:border-slate-800 flex flex-col h-full shadow-lg md:shadow-none transition-transform duration-200 ${
          isOpenMobile ? 'translate-x-0' : 'translate-x-full md:translate-x-0'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-xs">
              🌳
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 dark:text-slate-100 leading-none">
                الملاحظات المتداخلة
              </h1>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                Infinite Tree Notes
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onCreateRootNote}
              className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors cursor-pointer"
              title="إضافة ملاحظة رئيسية جديدة"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onCloseMobile}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 md:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Instant Search Bar */}
        <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="البحث السريع في الملاحظات والوسوم..."
              value={filterState.query}
              onChange={(e) => onUpdateFilter({ query: e.target.value })}
              className="w-full pr-9 pl-8 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-xl text-xs border border-transparent focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 focus:outline-hidden transition-all"
            />
            {filterState.query && (
              <button
                type="button"
                onClick={() => onUpdateFilter({ query: '' })}
                className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Nav Filters & Categories */}
        <div className="p-2 border-b border-slate-200 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-950/50 flex flex-wrap gap-1 text-[11px] font-medium">
          <button
            type="button"
            onClick={() => onUpdateFilter({ filterType: 'all', selectedTag: null, selectedColor: null })}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              filterState.filterType === 'all'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-bold shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
            }`}
          >
            <Folder className="w-3 h-3" />
            <span>الكل ({activeNotesCount})</span>
          </button>

          <button
            type="button"
            onClick={() => onUpdateFilter({ filterType: 'pinned', selectedTag: null, selectedColor: null })}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              filterState.filterType === 'pinned'
                ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 font-bold shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
            }`}
          >
            <Pin className="w-3 h-3 text-amber-500" />
            <span>المثبتة</span>
          </button>

          <button
            type="button"
            onClick={() => onUpdateFilter({ filterType: 'favorite', selectedTag: null, selectedColor: null })}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              filterState.filterType === 'favorite'
                ? 'bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 font-bold shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
            }`}
          >
            <Star className="w-3 h-3 text-rose-500" />
            <span>المفضلة</span>
          </button>

          <button
            type="button"
            onClick={() => onUpdateFilter({ filterType: 'archived', selectedTag: null, selectedColor: null })}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              filterState.filterType === 'archived'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-bold shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
            }`}
          >
            <Archive className="w-3 h-3" />
            <span>الأرشيف</span>
          </button>

          <button
            type="button"
            onClick={() => onUpdateFilter({ filterType: 'trash', selectedTag: null, selectedColor: null })}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
              filterState.filterType === 'trash'
                ? 'bg-white dark:bg-slate-800 text-rose-600 dark:text-rose-400 font-bold shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
            }`}
          >
            <Trash2 className="w-3 h-3" />
            <span>السلة</span>
          </button>
        </div>

        {/* Tags horizontal scroll if tags exist */}
        {allTags.length > 0 && (
          <div className="px-3 py-1.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[10px] text-slate-400 font-semibold shrink-0">الوسوم:</span>
            {allTags.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() =>
                  onUpdateFilter({
                    filterType: filterState.selectedTag === tag ? 'all' : 'tag',
                    selectedTag: filterState.selectedTag === tag ? null : tag,
                  })
                }
                className={`px-2 py-0.5 rounded-full text-[10px] whitespace-nowrap transition-colors cursor-pointer ${
                  filterState.selectedTag === tag
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        {/* Note Tree Scrollable Section */}
        <div className="flex-1 overflow-y-auto p-2 no-scrollbar">
          {tree.length === 0 ? (
            <div className="py-12 px-4 text-center">
              <FolderPlus className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600 mb-2" />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                لا توجد ملاحظات تطابق البحث أو الفلتر الحريري.
              </p>
              <button
                type="button"
                onClick={onCreateRootNote}
                className="mt-3 inline-flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة ملاحظة جديدة</span>
              </button>
            </div>
          ) : (
            tree.map((node) => renderTreeNode(node))
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-xs flex items-center justify-between">
          <span className="flex items-center gap-1 text-[11px]">
            <Layers className="w-3.5 h-3.5 text-blue-500" />
            إجمالي الملاحظات: <strong>{activeNotesCount}</strong>
          </span>

          {onOpenAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              className="px-2 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer border border-indigo-200 dark:border-indigo-800/50"
              title="الدخول إلى لوحة الإدارة"
            >
              <ShieldCheck className="w-3 h-3 text-indigo-500" />
              <span>لوحة الإدارة</span>
            </button>
          )}

          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            حفظ تلقائي
          </span>
        </div>
      </aside>
    </>
  );
};
