import React from 'react';
import { ShieldCheck, KeyRound, Lock, UserCheck, AlertOctagon, Check, X, ShieldAlert } from 'lucide-react';
import { AuditLogItem } from '../../types/admin';

interface AdminSecurityTabProps {
  logs: AuditLogItem[];
}

const ROLE_PERMISSIONS = [
  { feature: 'إدارة المستخدمين وحذف الحسابات', superAdmin: true, admin: true, moderator: false, support: false },
  { feature: 'تعديل أسعار الباقات والاشتراكات', superAdmin: true, admin: false, moderator: false, support: false },
  { feature: 'عرض واستعادة كافة الملاحظات System-wide', superAdmin: true, admin: true, moderator: true, support: false },
  { feature: 'تصدير وسحب سجلات التدقيق (Audit Logs)', superAdmin: true, admin: true, moderator: false, support: false },
  { feature: 'التحكم بإعدادات الصيانة و 2FA', superAdmin: true, admin: true, moderator: false, support: false },
  { feature: 'إرسال الإشعارات والتنبيهات المباشرة', superAdmin: true, admin: true, moderator: true, support: true },
  { feature: 'إعادة تعيين كلمة مرور المستخدم', superAdmin: true, admin: true, moderator: false, support: true },
];

export const AdminSecurityTab: React.FC<AdminSecurityTabProps> = ({ logs }) => {
  const failedLogins = logs.filter(l => l.status === 'warning' || l.status === 'error');

  return (
    <div className="space-y-6 animate-in fade-in duration-200 select-none text-xs">
      {/* 2FA & Encryption Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold">
            <ShieldCheck className="w-5 h-5" />
            <span>حماية التحقق الثنائي (2FA)</span>
          </div>
          <p className="text-slate-500 text-[11px]">مفعل ومجبر لجميع عمليات المشرفين في المنصة.</p>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold">
            <Lock className="w-5 h-5" />
            <span>تشفير قواعد البيانات AES-256</span>
          </div>
          <p className="text-slate-500 text-[11px]">تشفير متكامل أثناء النقل والتخزين المشفر.</p>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold">
            <AlertOctagon className="w-5 h-5" />
            <span>محاولات الدخول الفاشلة ({failedLogins.length})</span>
          </div>
          <p className="text-slate-500 text-[11px]">مراقبة تلقائية لمنع هجمات التخمين Brute-force.</p>
        </div>
      </div>

      {/* Permissions Matrix */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-indigo-500" />
          <span>مصفوفة الصلاحيات حسب أدوار المشرفين (Permissions Matrix)</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold bg-slate-50 dark:bg-slate-800/40">
                <th className="py-3 px-3">الميزة / الصلاحية</th>
                <th className="py-3 px-3 text-center">Super Admin</th>
                <th className="py-3 px-3 text-center">Admin</th>
                <th className="py-3 px-3 text-center">Moderator</th>
                <th className="py-3 px-3 text-center">Support</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {ROLE_PERMISSIONS.map((p, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">{p.feature}</td>
                  <td className="py-3 px-3 text-center">
                    {p.superAdmin ? <Check className="w-4 h-4 text-emerald-500 mx-auto" /> : <X className="w-4 h-4 text-rose-400 mx-auto" />}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {p.admin ? <Check className="w-4 h-4 text-emerald-500 mx-auto" /> : <X className="w-4 h-4 text-rose-400 mx-auto" />}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {p.moderator ? <Check className="w-4 h-4 text-emerald-500 mx-auto" /> : <X className="w-4 h-4 text-rose-400 mx-auto" />}
                  </td>
                  <td className="py-3 px-3 text-center">
                    {p.support ? <Check className="w-4 h-4 text-emerald-500 mx-auto" /> : <X className="w-4 h-4 text-rose-400 mx-auto" />}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
