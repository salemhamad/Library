export interface TaskItem {
  id: string;
  text: string;
  completed: boolean;
  dueDate?: string | null;
  priority?: 'low' | 'medium' | 'high';
  reminder?: string | null;
}

export interface AttachmentItem {
  id: string;
  name: string;
  type: 'image' | 'video' | 'audio' | 'pdf' | 'doc' | 'sheet' | 'ppt' | 'archive' | 'link' | 'file';
  url: string;
  size?: number;
  createdAt: string;
}

export interface Note {
  id: string;
  parentId: string | null;
  path: string; // e.g. "/root/child1/child2"
  depth: number; // 0 for root notes, 1, 2, 3... infinite depth
  title: string;
  content: string; // HTML or Markdown
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
  tags: string[];
  color: string; // preset color name or hex
  icon?: string; // emoji or icon identifier
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  isDeleted: boolean; // Trash status
  sortOrder: number;
  childrenCount: number;
  tasks: TaskItem[];
  attachments: AttachmentItem[];
  coverImage?: string | null;
  wordCount: number;
  characterCount: number;
  readingTime: number; // in minutes
}

export interface NoteTreeNode extends Note {
  children: NoteTreeNode[];
  isExpanded?: boolean;
}

export type FilterType = 
  | 'all' 
  | 'pinned' 
  | 'favorite' 
  | 'archived' 
  | 'trash' 
  | 'has_images' 
  | 'has_files' 
  | 'has_tasks' 
  | 'tag' 
  | 'color'
  | 'recent';

export type SortOption = 'updatedAt' | 'createdAt' | 'title' | 'depth' | 'sortOrder';
export type SortDirection = 'asc' | 'desc';

export interface FilterState {
  query: string;
  filterType: FilterType;
  selectedTag: string | null;
  selectedColor: string | null;
  sortBy: SortOption;
  sortDirection: SortDirection;
}

export type EditorViewMode = 'edit' | 'preview' | 'split' | 'readonly';

export interface BreadcrumbItem {
  id: string;
  title: string;
}

export interface ColorPreset {
  id: string;
  name: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  hex: string;
}

export interface AIServicePayload {
  content?: string;
  text?: string;
  style?: string;
  targetLang?: string;
  prompt?: string;
  message?: string;
  noteContext?: string;
}
