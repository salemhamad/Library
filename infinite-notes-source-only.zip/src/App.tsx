import React, { useState, useEffect, useMemo } from 'react';
import { 
  Menu, Moon, Sun, Plus, Download, Upload, Keyboard, 
  Folder, Layers, AlertCircle, FileText, Settings, Check, HelpCircle, SlidersHorizontal
} from 'lucide-react';
import { Note, NoteTreeNode, FilterState, EditorViewMode, TaskItem, AttachmentItem } from './types';
import { 
  loadAllNotes, saveAllNotes, buildNoteTree, getBreadcrumbPath, 
  createNewNote, moveNoteToParent, setNoteDeleteStatus, duplicateNoteWithSubtree, 
  filterAndSearchNotes, getAllUniqueTags, calculateNoteStats, updateChildrenCounts 
} from './services/storage';
import { NoteTreeSidebar } from './components/Sidebar/NoteTreeSidebar';
import { Breadcrumb } from './components/Breadcrumb';
import { RichTextEditor } from './components/Editor/RichTextEditor';
import { NoteTasksManager } from './components/Tasks/NoteTasksManager';
import { AttachmentsGallery } from './components/Media/AttachmentsGallery';
import { MoveNoteModal } from './components/Modals/MoveNoteModal';
import { ShortcutsModal } from './components/Modals/ShortcutsModal';
import { AdminLayout } from './components/Admin/AdminLayout';
import { AdminAuthModal } from './components/Admin/AdminAuthModal';
import { getAdminSession } from './services/adminStorage';

export default function App() {
  const [notes, setNotes] = useState<Note[]>(() => loadAllNotes());
  const [activeNoteId, setActiveNoteId] = useState<string | null>(() => {
    const loaded = loadAllNotes();
    return loaded.length > 0 ? loaded[0].id : null;
  });

  const [filterState, setFilterState] = useState<FilterState>({
    query: '',
    filterType: 'all',
    selectedTag: null,
    selectedColor: null,
    sortBy: 'updatedAt',
    sortDirection: 'desc',
  });

  const [viewMode, setViewMode] = useState<EditorViewMode>('edit');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('theme_mode') === 'dark';
  });

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState(false);
  const [moveNoteId, setMoveNoteId] = useState<string | null>(null);
  const [isToolbarOpen, setIsToolbarOpen] = useState(true);

  // Admin Portal State
  const [appMode, setAppMode] = useState<'user' | 'admin'>(() => {
    return window.location.hash === '#admin' || window.location.pathname.startsWith('/admin') ? 'admin' : 'user';
  });
  const [isAdminAuthOpen, setIsAdminAuthOpen] = useState(false);

  // Sync Hash changes (e.g., #admin)
  useEffect(() => {
    const handleHashChange = () => {
      if (window.location.hash === '#admin' || window.location.pathname.startsWith('/admin')) {
        setAppMode('admin');
      } else {
        setAppMode('user');
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Apply dark mode class to html document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme_mode', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme_mode', 'light');
    }
  }, [isDarkMode]);

  // Save notes whenever state updates
  useEffect(() => {
    saveAllNotes(notes);
  }, [notes]);

  // Filtered and Tree notes
  const filteredNotes = useMemo(() => {
    return filterAndSearchNotes(notes, filterState);
  }, [notes, filterState]);

  const tree = useMemo(() => {
    return buildNoteTree(filteredNotes, null, filterState.filterType !== 'trash');
  }, [filteredNotes, filterState.filterType]);

  const activeNote = useMemo(() => {
    return notes.find((n) => n.id === activeNoteId) || null;
  }, [notes, activeNoteId]);

  const breadcrumbItems = useMemo(() => {
    return getBreadcrumbPath(activeNoteId, notes);
  }, [activeNoteId, notes]);

  const allTags = useMemo(() => {
    return getAllUniqueTags(notes);
  }, [notes]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        if (e.shiftKey && activeNoteId) {
          handleCreateSubNote(activeNoteId);
        } else {
          handleCreateRootNote();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeNoteId, notes]);

  // Actions
  const handleCreateRootNote = () => {
    const { newNote, updatedNotes } = createNewNote(notes, null, 'ملاحظة جديدة');
    setNotes(updatedNotes);
    setActiveNoteId(newNote.id);
  };

  const handleCreateSubNote = (parentId: string) => {
    const { newNote, updatedNotes } = createNewNote(notes, parentId, 'ملاحظة فرعية جديد');
    setNotes(updatedNotes);
    setActiveNoteId(newNote.id);
  };

  const handleUpdateNoteContent = (content: string) => {
    if (!activeNoteId) return;
    const stats = calculateNoteStats(content);
    setNotes((prev) =>
      prev.map((n) =>
        n.id === activeNoteId
          ? {
              ...n,
              content,
              updatedAt: new Date().toISOString(),
              wordCount: stats.wordCount,
              characterCount: stats.characterCount,
              readingTime: stats.readingTime,
            }
          : n
      )
    );
  };

  const handleUpdateNoteTitle = (title: string) => {
    if (!activeNoteId) return;
    setNotes((prev) =>
      prev.map((n) =>
        n.id === activeNoteId
          ? { ...n, title, updatedAt: new Date().toISOString() }
          : n
      )
    );
  };

  const handleRenameNote = (id: string, newTitle: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, title: newTitle, updatedAt: new Date().toISOString() } : n))
    );
  };

  const handleDuplicateNote = (id: string) => {
    const updated = duplicateNoteWithSubtree(notes, id);
    setNotes(updated);
  };

  const handleConfirmMove = (noteId: string, newParentId: string | null) => {
    const updated = moveNoteToParent(notes, noteId, newParentId);
    setNotes(updated);
  };

  const handleTogglePin = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const handleToggleFavorite = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isFavorite: !n.isFavorite } : n))
    );
  };

  const handleToggleArchive = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isArchived: !n.isArchived } : n))
    );
  };

  const handleDeleteNote = (id: string, permanent = false) => {
    const updated = setNoteDeleteStatus(notes, id, true, permanent);
    setNotes(updated);
    if (activeNoteId === id) {
      const remaining = updated.filter((n) => !n.isDeleted);
      setActiveNoteId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  const handleRestoreNote = (id: string) => {
    const updated = setNoteDeleteStatus(notes, id, false);
    setNotes(updated);
  };

  const handleChangeColor = (id: string, color: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, color } : n))
    );
  };

  const handleUpdateTasks = (tasks: TaskItem[]) => {
    if (!activeNoteId) return;
    setNotes((prev) =>
      prev.map((n) => (n.id === activeNoteId ? { ...n, tasks } : n))
    );
  };

  const handleUpdateAttachments = (attachments: AttachmentItem[]) => {
    if (!activeNoteId) return;
    setNotes((prev) =>
      prev.map((n) => (n.id === activeNoteId ? { ...n, attachments } : n))
    );
  };

  // Export / Import Backup JSON
  const handleExportBackup = () => {
    const json = JSON.stringify(notes, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `notes-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (Array.isArray(parsed)) {
            const updated = updateChildrenCounts(parsed);
            setNotes(updated);
            saveAllNotes(updated);
            if (updated.length > 0) setActiveNoteId(updated[0].id);
            alert('تم استيراد نسخة الملاحظات بنجاح!');
          }
        } catch (err) {
          alert('ملف النسخة الاحتياطية غير صالح.');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleOpenAdminPortal = () => {
    const session = getAdminSession();
    if (session.isAuthenticated) {
      setAppMode('admin');
      window.location.hash = 'admin';
    } else {
      setIsAdminAuthOpen(true);
    }
  };

  if (appMode === 'admin') {
    const adminSession = getAdminSession();
    if (adminSession.isAuthenticated) {
      return (
        <AdminLayout
          onSwitchToUserApp={() => {
            setAppMode('user');
            window.location.hash = '';
          }}
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        />
      );
    }
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans dir-rtl">
      {/* Admin Auth Modal if triggered */}
      {isAdminAuthOpen && (
        <AdminAuthModal
          isOpen={isAdminAuthOpen}
          onClose={() => setIsAdminAuthOpen(false)}
          onLoginSuccess={() => {
            setIsAdminAuthOpen(false);
            setAppMode('admin');
            window.location.hash = 'admin';
          }}
        />
      )}

      {/* Sidebar Tree Navigation */}
      <NoteTreeSidebar
        tree={tree}
        allNotes={notes}
        activeNoteId={activeNoteId}
        activeNote={activeNote}
        onUpdateTasks={handleUpdateTasks}
        onUpdateAttachments={handleUpdateAttachments}
        onSelectNote={(id) => {
          setActiveNoteId(id);
          setIsMobileSidebarOpen(false);
        }}
        onCreateRootNote={handleCreateRootNote}
        onCreateSubNote={handleCreateSubNote}
        onRenameNote={handleRenameNote}
        onDuplicateNote={handleDuplicateNote}
        onMoveNoteClick={(id) => setMoveNoteId(id)}
        onTogglePin={handleTogglePin}
        onToggleFavorite={handleToggleFavorite}
        onToggleArchive={handleToggleArchive}
        onDeleteNote={handleDeleteNote}
        onRestoreNote={handleRestoreNote}
        onChangeColor={handleChangeColor}
        filterState={filterState}
        onUpdateFilter={(up) => setFilterState((prev) => ({ ...prev, ...up }))}
        allTags={allTags}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        onOpenAdmin={handleOpenAdminPortal}
      />

      {/* Main App Workspace */}
      <main className="flex-1 flex flex-col h-full min-w-0 overflow-hidden bg-white dark:bg-slate-900">
        {/* Top Navigation Header */}
        <header className="px-4 py-2.5 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shadow-2xs select-none">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsMobileSidebarOpen(true)}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 md:hidden cursor-pointer"
              title="القائمة الجانبية"
            >
              <Menu className="w-5 h-5" />
            </button>

            <span className="text-sm font-extrabold text-slate-900 dark:text-slate-100 hidden sm:inline">
              🌳 نظام الملاحظات المتداخلة
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Dark Mode Toggle */}
            <button
              type="button"
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-2xs hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              title={isDarkMode ? 'الوضع الفاتح' : 'الوضع الداكن'}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
            </button>

            {/* Shortcuts Modal Button */}
            <button
              type="button"
              onClick={() => setIsShortcutsModalOpen(true)}
              className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-2xs hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              title="اختصارات لوحة المفاتيح"
            >
              <Keyboard className="w-4 h-4" />
            </button>

            {/* Export / Import Backup */}
            <button
              type="button"
              onClick={handleExportBackup}
              className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-2xs hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer hidden sm:flex"
              title="تصدير نسخة احتياطية JSON"
            >
              <Download className="w-4 h-4" />
            </button>

            <label className="p-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-2xs hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer hidden sm:flex" title="استيراد نسخة احتياطية JSON">
              <Upload className="w-4 h-4" />
              <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>
        </header>

        {/* Breadcrumb Path Bar */}
        <Breadcrumb
          items={breadcrumbItems}
          currentNote={activeNote}
          allNotes={notes}
          onSelectNote={setActiveNoteId}
          onCreateSubNote={handleCreateSubNote}
          onToggleFavorite={handleToggleFavorite}
          onTogglePin={handleTogglePin}
          onOpenShortcuts={() => setIsShortcutsModalOpen(true)}
          viewMode={viewMode}
          onChangeViewMode={setViewMode}
          onSelectColor={(c) => activeNoteId && handleChangeColor(activeNoteId, c)}
          isToolbarOpen={isToolbarOpen}
          onToggleToolbar={() => setIsToolbarOpen(!isToolbarOpen)}
        />

        {/* Workspace Body */}
        {activeNote ? (
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            {/* Trash indicator banner if note is deleted */}
            {activeNote.isDeleted && (
              <div className="bg-rose-500 text-white px-4 py-2 text-xs font-bold flex items-center justify-between">
                <span>⚠️ هذه الملاحظة موجودة داخل سلة المهملات.</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleRestoreNote(activeNote.id)}
                    className="px-3 py-1 bg-white text-rose-700 rounded-lg text-xs font-bold hover:bg-slate-100"
                  >
                    استعادة الملاحظة
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteNote(activeNote.id, true)}
                    className="px-3 py-1 bg-rose-900 text-white rounded-lg text-xs font-bold hover:bg-rose-950"
                  >
                    حذف نهائي
                  </button>
                </div>
              </div>
            )}

            {/* Split view vs Single Editor */}
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
              <div className="flex-1 flex flex-col h-full min-w-0">
                <RichTextEditor
                  note={activeNote}
                  onChangeContent={handleUpdateNoteContent}
                  onChangeTitle={handleUpdateNoteTitle}
                  viewMode={viewMode}
                  isToolbarOpen={isToolbarOpen}
                  onToggleToolbar={() => setIsToolbarOpen(!isToolbarOpen)}
                />
              </div>

              {/* Split Mode Rendered Preview Panel */}
              {viewMode === 'split' && (
                <div className="w-full md:w-1/2 border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 overflow-y-auto">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                    المعاينة المباشرة (Live Preview):
                  </h3>
                  <h1 className="text-2xl font-bold mb-4">{activeNote.title}</h1>
                  <div
                    dangerouslySetInnerHTML={{ __html: activeNote.content }}
                    className="prose dark:prose-invert max-w-none text-sm"
                  />
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50 dark:bg-slate-900">
            <div className="w-16 h-16 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-4 text-2xl shadow-sm">
              🌳
            </div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">
              مرحباً بك في نظام الملاحظات المتداخلة
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mb-6">
              اختر ملاحظة من الشريط الجانبي للتعديل عليها أو اضغط على الزر أدناه لإنشاء ملاحظة جديدة.
            </p>
            <button
              type="button"
              onClick={handleCreateRootNote}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إنشاء ملاحظة جديدة</span>
            </button>
          </div>
        )}
      </main>

      {/* Global Modals */}
      <MoveNoteModal
        isOpen={!!moveNoteId}
        onClose={() => setMoveNoteId(null)}
        noteToMoveId={moveNoteId}
        tree={tree}
        allNotes={notes}
        onConfirmMove={handleConfirmMove}
      />

      <ShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
      />
    </div>
  );
}
