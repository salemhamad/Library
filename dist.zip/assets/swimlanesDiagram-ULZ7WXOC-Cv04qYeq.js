import{c as e,s as r}from"./flowDiagram-UKHOOZJN-dqW1Jdrr.js";import{_ as a}from"./index-D3fzk0UA.js";import"./chunk-5VM5RSS4-Bzv6ocUj.js";import"./chunk-XXDRQBXY-C8yz9Q-r.js";import"./chunk-KBJHAD2P-MwVztrqE.js";import"./chunk-2GRJ4B5K-CIw6LwRF.js";import"./channel-kXQ2qb46.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
