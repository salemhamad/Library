import{aj as o,ak as n}from"./index-DLVy-3XD.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
