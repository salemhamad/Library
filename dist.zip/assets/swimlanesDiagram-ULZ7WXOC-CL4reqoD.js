import{c as e,s as r}from"./flowDiagram-UKHOOZJN-Caebhnhy.js";import{_ as a}from"./index-DLVy-3XD.js";import"./chunk-5VM5RSS4-B5kNaBgD.js";import"./chunk-XXDRQBXY-6JFXc_te.js";import"./chunk-KBJHAD2P-CFVqo7NE.js";import"./chunk-2GRJ4B5K-DbQv34Qb.js";import"./channel-CHQMx_uh.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
