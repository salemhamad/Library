import{c as e,s as r}from"./flowDiagram-UKHOOZJN-DGiq0o3I.js";import{_ as a}from"./index-B9l2WbfX.js";import"./chunk-5VM5RSS4-kdXrAisF.js";import"./chunk-XXDRQBXY-MCp8Lv5M.js";import"./chunk-KBJHAD2P-Deu4IX9X.js";import"./chunk-2GRJ4B5K-aIiKhTco.js";import"./channel-lnwl-twR.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
