import{c as e,s as r}from"./flowDiagram-UKHOOZJN-MI9GJO88.js";import{_ as a}from"./index-CwZ6ZHq0.js";import"./chunk-5VM5RSS4-D1_QZkKn.js";import"./chunk-XXDRQBXY-o_v-akxi.js";import"./chunk-KBJHAD2P-BcMW7nXU.js";import"./chunk-2GRJ4B5K-Bzh-fwJA.js";import"./channel--QYpNibi.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
