import{aj as o,ak as n}from"./index-D3fzk0UA.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
