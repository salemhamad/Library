import{aj as o,ak as n}from"./index-CwZ6ZHq0.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
