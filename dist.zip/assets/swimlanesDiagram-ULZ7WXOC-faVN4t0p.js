import{c as e,s as r}from"./flowDiagram-UKHOOZJN-6Ep61WTM.js";import{_ as a}from"./index-B76mFhn3.js";import"./chunk-5VM5RSS4-7RIFrGRZ.js";import"./chunk-XXDRQBXY-DWyHoHIR.js";import"./chunk-KBJHAD2P-CQ7uRWtH.js";import"./chunk-2GRJ4B5K-V94qEy5U.js";import"./channel-DudfoEK2.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
