import{c as e,s as r}from"./flowDiagram-UKHOOZJN-CRcyGNrz.js";import{_ as a}from"./index-BXzdSNTM.js";import"./chunk-5VM5RSS4-B7SMKTea.js";import"./chunk-XXDRQBXY-v1WIAf2p.js";import"./chunk-KBJHAD2P-CBNqA3nT.js";import"./chunk-2GRJ4B5K-B_b49b1c.js";import"./channel-AACfXDK1.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
