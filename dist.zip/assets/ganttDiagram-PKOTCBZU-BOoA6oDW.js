import{be,bf as Re,bg as Te,bh as we,bi as _e,bj as Ot,bk as He,bb as Ft,g as Be,s as qe,o as Ge,n as Xe,a as je,b as Ue,_ as l,c as ht,d as Tt,bl as Ze,bm as Qe,bn as Ke,e as Je,E as tr,bo as U,l as lt,bp as ae,bq as oe,br as er,bs as rr,bt as nr,bu as ir,bv as sr,bw as ar,bx as or,by as ce,bz as le,bA as ue,bB as de,bC as fe,k as cr,j as lr,p as ur,x as dr}from"./index-C45OdmOW.js";function fr(t){return t}var _t=1,Wt=2,Ht=3,wt=4,he=1e-6;function hr(t){return"translate("+t+",0)"}function mr(t){return"translate(0,"+t+")"}function kr(t){return e=>+t(e)}function yr(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),r=>+t(r)+e}function gr(){return!this.__axis}function De(t,e){var r=[],n=null,s=null,m=6,f=6,T=3,C=typeof window<"u"&&window.devicePixelRatio>1?0:.5,L=t===_t||t===wt?-1:1,w=t===wt||t===Wt?"x":"y",P=t===_t||t===Ht?hr:mr;function _(D){var G=n??(e.ticks?e.ticks.apply(e,r):e.domain()),R=s??(e.tickFormat?e.tickFormat.apply(e,r):fr),g=Math.max(m,0)+T,M=e.range(),W=+M[0]+C,O=+M[M.length-1]+C,H=(e.bandwidth?yr:kr)(e.copy(),C),z=D.selection?D.selection():D,I=z.selectAll(".domain").data([null]),x=z.selectAll(".tick").data(G,e).order(),k=x.exit(),E=x.enter().append("g").attr("class","tick"),h=x.select("line"),b=x.select("text");I=I.merge(I.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),x=x.merge(E),h=h.merge(E.append("line").attr("stroke","currentColor").attr(w+"2",L*m)),b=b.merge(E.append("text").attr("fill","currentColor").attr(w,L*g).attr("dy",t===_t?"0em":t===Ht?"0.71em":"0.32em")),D!==z&&(I=I.transition(D),x=x.transition(D),h=h.transition(D),b=b.transition(D),k=k.transition(D).attr("opacity",he).attr("transform",function(v){return isFinite(v=H(v))?P(v+C):this.getAttribute("transform")}),E.attr("opacity",he).attr("transform",function(v){var p=this.parentNode.__axis;return P((p&&isFinite(p=p(v))?p:H(v))+C)})),k.remove(),I.attr("d",t===wt||t===Wt?f?"M"+L*f+","+W+"H"+C+"V"+O+"H"+L*f:"M"+C+","+W+"V"+O:f?"M"+W+","+L*f+"V"+C+"H"+O+"V"+L*f:"M"+W+","+C+"H"+O),x.attr("opacity",1).attr("transform",function(v){return P(H(v)+C)}),h.attr(w+"2",L*m),b.attr(w,L*g).text(R),z.filter(gr).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===Wt?"start":t===wt?"end":"middle"),z.each(function(){this.__axis=H})}return _.scale=function(D){return arguments.length?(e=D,_):e},_.ticks=function(){return r=Array.from(arguments),_},_.tickArguments=function(D){return arguments.length?(r=D==null?[]:Array.from(D),_):r.slice()},_.tickValues=function(D){return arguments.length?(n=D==null?null:Array.from(D),_):n&&n.slice()},_.tickFormat=function(D){return arguments.length?(s=D,_):s},_.tickSize=function(D){return arguments.length?(m=f=+D,_):m},_.tickSizeInner=function(D){return arguments.length?(m=+D,_):m},_.tickSizeOuter=function(D){return arguments.length?(f=+D,_):f},_.tickPadding=function(D){return arguments.length?(T=+D,_):T},_.offset=function(D){return arguments.length?(C=+D,_):C},_}function pr(t){return De(_t,t)}function vr(t){return De(Ht,t)}const xr=Math.PI/180,br=180/Math.PI,Yt=18,Se=.96422,Ce=1,Me=.82521,Ee=4/29,mt=6/29,Ie=3*mt*mt,Tr=mt*mt*mt;function Ye(t){if(t instanceof rt)return new rt(t.l,t.a,t.b,t.opacity);if(t instanceof it)return $e(t);t instanceof be||(t=Re(t));var e=zt(t.r),r=zt(t.g),n=zt(t.b),s=Pt((.2225045*e+.7168786*r+.0606169*n)/Ce),m,f;return e===r&&r===n?m=f=s:(m=Pt((.4360747*e+.3850649*r+.1430804*n)/Se),f=Pt((.0139322*e+.0971045*r+.7141733*n)/Me)),new rt(116*s-16,500*(m-s),200*(s-f),t.opacity)}function wr(t,e,r,n){return arguments.length===1?Ye(t):new rt(t,e,r,n??1)}function rt(t,e,r,n){this.l=+t,this.a=+e,this.b=+r,this.opacity=+n}Te(rt,wr,we(_e,{brighter(t){return new rt(this.l+Yt*(t??1),this.a,this.b,this.opacity)},darker(t){return new rt(this.l-Yt*(t??1),this.a,this.b,this.opacity)},rgb(){var t=(this.l+16)/116,e=isNaN(this.a)?t:t+this.a/500,r=isNaN(this.b)?t:t-this.b/200;return e=Se*Nt(e),t=Ce*Nt(t),r=Me*Nt(r),new be(Vt(3.1338561*e-1.6168667*t-.4906146*r),Vt(-.9787684*e+1.9161415*t+.033454*r),Vt(.0719453*e-.2289914*t+1.4052427*r),this.opacity)}}));function Pt(t){return t>Tr?Math.pow(t,1/3):t/Ie+Ee}function Nt(t){return t>mt?t*t*t:Ie*(t-Ee)}function Vt(t){return 255*(t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055)}function zt(t){return(t/=255)<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4)}function _r(t){if(t instanceof it)return new it(t.h,t.c,t.l,t.opacity);if(t instanceof rt||(t=Ye(t)),t.a===0&&t.b===0)return new it(NaN,0<t.l&&t.l<100?0:NaN,t.l,t.opacity);var e=Math.atan2(t.b,t.a)*br;return new it(e<0?e+360:e,Math.sqrt(t.a*t.a+t.b*t.b),t.l,t.opacity)}function Bt(t,e,r,n){return arguments.length===1?_r(t):new it(t,e,r,n??1)}function it(t,e,r,n){this.h=+t,this.c=+e,this.l=+r,this.opacity=+n}function $e(t){if(isNaN(t.h))return new rt(t.l,0,0,t.opacity);var e=t.h*xr;return new rt(t.l,Math.cos(e)*t.c,Math.sin(e)*t.c,t.opacity)}Te(it,Bt,we(_e,{brighter(t){return new it(this.h,this.c,this.l+Yt*(t??1),this.opacity)},darker(t){return new it(this.h,this.c,this.l-Yt*(t??1),this.opacity)},rgb(){return $e(this).rgb()}}));function Dr(t){return function(e,r){var n=t((e=Bt(e)).h,(r=Bt(r)).h),s=Ot(e.c,r.c),m=Ot(e.l,r.l),f=Ot(e.opacity,r.opacity);return function(T){return e.h=n(T),e.c=s(T),e.l=m(T),e.opacity=f(T),e+""}}}const Sr=Dr(He);var Dt={exports:{}},Cr=Dt.exports,me;function Mr(){return me||(me=1,(function(t,e){(function(r,n){t.exports=n()})(Cr,(function(){var r="day";return function(n,s,m){var f=function(L){return L.add(4-L.isoWeekday(),r)},T=s.prototype;T.isoWeekYear=function(){return f(this).year()},T.isoWeek=function(L){if(!this.$utils().u(L))return this.add(7*(L-this.isoWeek()),r);var w,P,_,D,G=f(this),R=(w=this.isoWeekYear(),P=this.$u,_=(P?m.utc:m)().year(w).startOf("year"),D=4-_.isoWeekday(),_.isoWeekday()>4&&(D+=7),_.add(D,r));return G.diff(R,"week")+1},T.isoWeekday=function(L){return this.$utils().u(L)?this.day()||7:this.day(this.day()%7?L:L-7)};var C=T.startOf;T.startOf=function(L,w){var P=this.$utils(),_=!!P.u(w)||w;return P.p(L)==="isoweek"?_?this.date(this.date()-(this.isoWeekday()-1)).startOf("day"):this.date(this.date()-1-(this.isoWeekday()-1)+7).endOf("day"):C.bind(this)(L,w)}}}))})(Dt)),Dt.exports}var Er=Mr();const Ir=Ft(Er);var St={exports:{}},Yr=St.exports,ke;function $r(){return ke||(ke=1,(function(t,e){(function(r,n){t.exports=n()})(Yr,(function(){var r={LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},n=/(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,s=/\d/,m=/\d\d/,f=/\d\d?/,T=/\d*[^-_:/,()\s\d]+/,C={},L=function(g){return(g=+g)+(g>68?1900:2e3)},w=function(g){return function(M){this[g]=+M}},P=[/[+-]\d\d:?(\d\d)?|Z/,function(g){(this.zone||(this.zone={})).offset=(function(M){if(!M||M==="Z")return 0;var W=M.match(/([+-]|\d\d)/g),O=60*W[1]+(+W[2]||0);return O===0?0:W[0]==="+"?-O:O})(g)}],_=function(g){var M=C[g];return M&&(M.indexOf?M:M.s.concat(M.f))},D=function(g,M){var W,O=C.meridiem;if(O){for(var H=1;H<=24;H+=1)if(g.indexOf(O(H,0,M))>-1){W=H>12;break}}else W=g===(M?"pm":"PM");return W},G={A:[T,function(g){this.afternoon=D(g,!1)}],a:[T,function(g){this.afternoon=D(g,!0)}],Q:[s,function(g){this.month=3*(g-1)+1}],S:[s,function(g){this.milliseconds=100*+g}],SS:[m,function(g){this.milliseconds=10*+g}],SSS:[/\d{3}/,function(g){this.milliseconds=+g}],s:[f,w("seconds")],ss:[f,w("seconds")],m:[f,w("minutes")],mm:[f,w("minutes")],H:[f,w("hours")],h:[f,w("hours")],HH:[f,w("hours")],hh:[f,w("hours")],D:[f,w("day")],DD:[m,w("day")],Do:[T,function(g){var M=C.ordinal,W=g.match(/\d+/);if(this.day=W[0],M)for(var O=1;O<=31;O+=1)M(O).replace(/\[|\]/g,"")===g&&(this.day=O)}],w:[f,w("week")],ww:[m,w("week")],M:[f,w("month")],MM:[m,w("month")],MMM:[T,function(g){var M=_("months"),W=(_("monthsShort")||M.map((function(O){return O.slice(0,3)}))).indexOf(g)+1;if(W<1)throw new Error;this.month=W%12||W}],MMMM:[T,function(g){var M=_("months").indexOf(g)+1;if(M<1)throw new Error;this.month=M%12||M}],Y:[/[+-]?\d+/,w("year")],YY:[m,function(g){this.year=L(g)}],YYYY:[/\d{4}/,w("year")],Z:P,ZZ:P};function R(g){var M,W;M=g,W=C&&C.formats;for(var O=(g=M.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g,(function(h,b,v){var p=v&&v.toUpperCase();return b||W[v]||r[v]||W[p].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g,(function(a,d,y){return d||y.slice(1)}))}))).match(n),H=O.length,z=0;z<H;z+=1){var I=O[z],x=G[I],k=x&&x[0],E=x&&x[1];O[z]=E?{regex:k,parser:E}:I.replace(/^\[|\]$/g,"")}return function(h){for(var b={},v=0,p=0;v<H;v+=1){var a=O[v];if(typeof a=="string")p+=a.length;else{var d=a.regex,y=a.parser,u=h.slice(p),S=d.exec(u)[0];y.call(b,S),h=h.replace(S,"")}}return(function(i){var Y=i.afternoon;if(Y!==void 0){var o=i.hours;Y?o<12&&(i.hours+=12):o===12&&(i.hours=0),delete i.afternoon}})(b),b}}return function(g,M,W){W.p.customParseFormat=!0,g&&g.parseTwoDigitYear&&(L=g.parseTwoDigitYear);var O=M.prototype,H=O.parse;O.parse=function(z){var I=z.date,x=z.utc,k=z.args;this.$u=x;var E=k[1];if(typeof E=="string"){var h=k[2]===!0,b=k[3]===!0,v=h||b,p=k[2];b&&(p=k[2]),C=this.$locale(),!h&&p&&(C=W.Ls[p]),this.$d=(function(u,S,i,Y){try{if(["x","X"].indexOf(S)>-1)return new Date((S==="X"?1e3:1)*u);var o=R(S)(u),q=o.year,c=o.month,$=o.day,A=o.hours,V=o.minutes,F=o.seconds,B=o.milliseconds,N=o.zone,st=o.week,ot=new Date,vt=$||(q||c?1:ot.getDate()),dt=q||ot.getFullYear(),X=0;q&&!c||(X=c>0?c-1:ot.getMonth());var K,Z=A||0,ct=V||0,J=F||0,at=B||0;return N?new Date(Date.UTC(dt,X,vt,Z,ct,J,at+60*N.offset*1e3)):i?new Date(Date.UTC(dt,X,vt,Z,ct,J,at)):(K=new Date(dt,X,vt,Z,ct,J,at),st&&(K=Y(K).week(st).toDate()),K)}catch{return new Date("")}})(I,E,x,W),this.init(),p&&p!==!0&&(this.$L=this.locale(p).$L),v&&I!=this.format(E)&&(this.$d=new Date("")),C={}}else if(E instanceof Array)for(var a=E.length,d=1;d<=a;d+=1){k[1]=E[d-1];var y=W.apply(this,k);if(y.isValid()){this.$d=y.$d,this.$L=y.$L,this.init();break}d===a&&(this.$d=new Date(""))}else H.call(this,z)}}}))})(St)),St.exports}var Ar=$r();const Fr=Ft(Ar);var Ct={exports:{}},Lr=Ct.exports,ye;function Or(){return ye||(ye=1,(function(t,e){(function(r,n){t.exports=n()})(Lr,(function(){return function(r,n){var s=n.prototype,m=s.format;s.format=function(f){var T=this,C=this.$locale();if(!this.isValid())return m.bind(this)(f);var L=this.$utils(),w=(f||"YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g,(function(P){switch(P){case"Q":return Math.ceil((T.$M+1)/3);case"Do":return C.ordinal(T.$D);case"gggg":return T.weekYear();case"GGGG":return T.isoWeekYear();case"wo":return C.ordinal(T.week(),"W");case"w":case"ww":return L.s(T.week(),P==="w"?1:2,"0");case"W":case"WW":return L.s(T.isoWeek(),P==="W"?1:2,"0");case"k":case"kk":return L.s(String(T.$H===0?24:T.$H),P==="k"?1:2,"0");case"X":return Math.floor(T.$d.getTime()/1e3);case"x":return T.$d.getTime();case"z":return"["+T.offsetName()+"]";case"zzz":return"["+T.offsetName("long")+"]";default:return P}}));return m.bind(this)(w)}}}))})(Ct)),Ct.exports}var Wr=Or();const Pr=Ft(Wr);var Mt={exports:{}},Nr=Mt.exports,ge;function Vr(){return ge||(ge=1,(function(t,e){(function(r,n){t.exports=n()})(Nr,(function(){var r,n,s=1e3,m=6e4,f=36e5,T=864e5,C=31536e6,L=2628e6,w=/^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/,P=/\[([^\]]+)]|YYYY|YY|Y|M{1,2}|D{1,2}|H{1,2}|m{1,2}|s{1,2}|SSS/g,_={years:C,months:L,days:T,hours:f,minutes:m,seconds:s,milliseconds:1,weeks:6048e5},D=function(I){return I instanceof H},G=function(I,x,k){return new H(I,k,x.$l)},R=function(I){return n.p(I)+"s"},g=function(I){return I<0},M=function(I){return g(I)?Math.ceil(I):Math.floor(I)},W=function(I){return Math.abs(I)},O=function(I,x){return I?g(I)?{negative:!0,format:""+W(I)+x}:{negative:!1,format:""+I+x}:{negative:!1,format:""}},H=(function(){function I(k,E,h){var b=this;if(this.$d={},this.$l=h,k===void 0&&(this.$ms=0,this.parseFromMilliseconds()),E)return G(k*_[R(E)],this);if(typeof k=="number")return this.$ms=k,this.parseFromMilliseconds(),this;if(typeof k=="object")return Object.keys(k).forEach((function(a){b.$d[R(a)]=k[a]})),this.calMilliseconds(),this;if(typeof k=="string"){var v=k.match(w);if(v){var p=v.slice(2).map((function(a){return a!=null?Number(a):0}));return this.$d.years=p[0],this.$d.months=p[1],this.$d.weeks=p[2],this.$d.days=p[3],this.$d.hours=p[4],this.$d.minutes=p[5],this.$d.seconds=p[6],this.calMilliseconds(),this}}return this}var x=I.prototype;return x.calMilliseconds=function(){var k=this;this.$ms=Object.keys(this.$d).reduce((function(E,h){return E+(k.$d[h]||0)*_[h]}),0)},x.parseFromMilliseconds=function(){var k=this.$ms;this.$d.years=M(k/C),k%=C,this.$d.months=M(k/L),k%=L,this.$d.days=M(k/T),k%=T,this.$d.hours=M(k/f),k%=f,this.$d.minutes=M(k/m),k%=m,this.$d.seconds=M(k/s),k%=s,this.$d.milliseconds=k},x.toISOString=function(){var k=O(this.$d.years,"Y"),E=O(this.$d.months,"M"),h=+this.$d.days||0;this.$d.weeks&&(h+=7*this.$d.weeks);var b=O(h,"D"),v=O(this.$d.hours,"H"),p=O(this.$d.minutes,"M"),a=this.$d.seconds||0;this.$d.milliseconds&&(a+=this.$d.milliseconds/1e3,a=Math.round(1e3*a)/1e3);var d=O(a,"S"),y=k.negative||E.negative||b.negative||v.negative||p.negative||d.negative,u=v.format||p.format||d.format?"T":"",S=(y?"-":"")+"P"+k.format+E.format+b.format+u+v.format+p.format+d.format;return S==="P"||S==="-P"?"P0D":S},x.toJSON=function(){return this.toISOString()},x.format=function(k){var E=k||"YYYY-MM-DDTHH:mm:ss",h={Y:this.$d.years,YY:n.s(this.$d.years,2,"0"),YYYY:n.s(this.$d.years,4,"0"),M:this.$d.months,MM:n.s(this.$d.months,2,"0"),D:this.$d.days,DD:n.s(this.$d.days,2,"0"),H:this.$d.hours,HH:n.s(this.$d.hours,2,"0"),m:this.$d.minutes,mm:n.s(this.$d.minutes,2,"0"),s:this.$d.seconds,ss:n.s(this.$d.seconds,2,"0"),SSS:n.s(this.$d.milliseconds,3,"0")};return E.replace(P,(function(b,v){return v||String(h[b])}))},x.as=function(k){return this.$ms/_[R(k)]},x.get=function(k){var E=this.$ms,h=R(k);return h==="milliseconds"?E%=1e3:E=h==="weeks"?M(E/_[h]):this.$d[h],E||0},x.add=function(k,E,h){var b;return b=E?k*_[R(E)]:D(k)?k.$ms:G(k,this).$ms,G(this.$ms+b*(h?-1:1),this)},x.subtract=function(k,E){return this.add(k,E,!0)},x.locale=function(k){var E=this.clone();return E.$l=k,E},x.clone=function(){return G(this.$ms,this)},x.humanize=function(k){return r().add(this.$ms,"ms").locale(this.$l).fromNow(!k)},x.valueOf=function(){return this.asMilliseconds()},x.milliseconds=function(){return this.get("milliseconds")},x.asMilliseconds=function(){return this.as("milliseconds")},x.seconds=function(){return this.get("seconds")},x.asSeconds=function(){return this.as("seconds")},x.minutes=function(){return this.get("minutes")},x.asMinutes=function(){return this.as("minutes")},x.hours=function(){return this.get("hours")},x.asHours=function(){return this.as("hours")},x.days=function(){return this.get("days")},x.asDays=function(){return this.as("days")},x.weeks=function(){return this.get("weeks")},x.asWeeks=function(){return this.as("weeks")},x.months=function(){return this.get("months")},x.asMonths=function(){return this.as("months")},x.years=function(){return this.get("years")},x.asYears=function(){return this.as("years")},I})(),z=function(I,x,k){return I.add(x.years()*k,"y").add(x.months()*k,"M").add(x.days()*k,"d").add(x.hours()*k,"h").add(x.minutes()*k,"m").add(x.seconds()*k,"s").add(x.milliseconds()*k,"ms")};return function(I,x,k){r=k,n=k().$utils(),k.duration=function(b,v){var p=k.locale();return G(b,{$l:p},v)},k.isDuration=D;var E=x.prototype.add,h=x.prototype.subtract;x.prototype.add=function(b,v){return D(b)?z(this,b,1):E.bind(this)(b,v)},x.prototype.subtract=function(b,v){return D(b)?z(this,b,-1):h.bind(this)(b,v)}}}))})(Mt)),Mt.exports}var zr=Vr();const Rr=Ft(zr);var qt=(function(){var t=l(function(p,a,d,y){for(d=d||{},y=p.length;y--;d[p[y]]=a);return d},"o"),e=[6,8,10,12,13,14,15,16,17,18,20,21,22,23,24,25,26,27,28,29,30,31,33,35,36,38,40],r=[1,26],n=[1,27],s=[1,28],m=[1,29],f=[1,30],T=[1,31],C=[1,32],L=[1,33],w=[1,34],P=[1,9],_=[1,10],D=[1,11],G=[1,12],R=[1,13],g=[1,14],M=[1,15],W=[1,16],O=[1,19],H=[1,20],z=[1,21],I=[1,22],x=[1,23],k=[1,25],E=[1,35],h={trace:l(function(){},"trace"),yy:{},symbols_:{error:2,start:3,gantt:4,document:5,EOF:6,line:7,SPACE:8,statement:9,NL:10,weekday:11,weekday_monday:12,weekday_tuesday:13,weekday_wednesday:14,weekday_thursday:15,weekday_friday:16,weekday_saturday:17,weekday_sunday:18,weekend:19,weekend_friday:20,weekend_saturday:21,dateFormat:22,inclusiveEndDates:23,topAxis:24,axisFormat:25,tickInterval:26,excludes:27,includes:28,todayMarker:29,title:30,acc_title:31,acc_title_value:32,acc_descr:33,acc_descr_value:34,acc_descr_multiline_value:35,section:36,clickStatement:37,taskTxt:38,taskData:39,click:40,callbackname:41,callbackargs:42,href:43,clickStatementDebug:44,$accept:0,$end:1},terminals_:{2:"error",4:"gantt",6:"EOF",8:"SPACE",10:"NL",12:"weekday_monday",13:"weekday_tuesday",14:"weekday_wednesday",15:"weekday_thursday",16:"weekday_friday",17:"weekday_saturday",18:"weekday_sunday",20:"weekend_friday",21:"weekend_saturday",22:"dateFormat",23:"inclusiveEndDates",24:"topAxis",25:"axisFormat",26:"tickInterval",27:"excludes",28:"includes",29:"todayMarker",30:"title",31:"acc_title",32:"acc_title_value",33:"acc_descr",34:"acc_descr_value",35:"acc_descr_multiline_value",36:"section",38:"taskTxt",39:"taskData",40:"click",41:"callbackname",42:"callbackargs",43:"href"},productions_:[0,[3,3],[5,0],[5,2],[7,2],[7,1],[7,1],[7,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[19,1],[19,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,2],[9,2],[9,1],[9,1],[9,1],[9,2],[37,2],[37,3],[37,3],[37,4],[37,3],[37,4],[37,2],[44,2],[44,3],[44,3],[44,4],[44,3],[44,4],[44,2]],performAction:l(function(a,d,y,u,S,i,Y){var o=i.length-1;switch(S){case 1:return i[o-1];case 2:this.$=[];break;case 3:i[o-1].push(i[o]),this.$=i[o-1];break;case 4:case 5:this.$=i[o];break;case 6:case 7:this.$=[];break;case 8:u.setWeekday("monday");break;case 9:u.setWeekday("tuesday");break;case 10:u.setWeekday("wednesday");break;case 11:u.setWeekday("thursday");break;case 12:u.setWeekday("friday");break;case 13:u.setWeekday("saturday");break;case 14:u.setWeekday("sunday");break;case 15:u.setWeekend("friday");break;case 16:u.setWeekend("saturday");break;case 17:u.setDateFormat(i[o].substr(11)),this.$=i[o].substr(11);break;case 18:u.enableInclusiveEndDates(),this.$=i[o].substr(18);break;case 19:u.TopAxis(),this.$=i[o].substr(8);break;case 20:u.setAxisFormat(i[o].substr(11)),this.$=i[o].substr(11);break;case 21:u.setTickInterval(i[o].substr(13)),this.$=i[o].substr(13);break;case 22:u.setExcludes(i[o].substr(9)),this.$=i[o].substr(9);break;case 23:u.setIncludes(i[o].substr(9)),this.$=i[o].substr(9);break;case 24:u.setTodayMarker(i[o].substr(12)),this.$=i[o].substr(12);break;case 27:u.setDiagramTitle(i[o].substr(6)),this.$=i[o].substr(6);break;case 28:this.$=i[o].trim(),u.setAccTitle(this.$);break;case 29:case 30:this.$=i[o].trim(),u.setAccDescription(this.$);break;case 31:u.addSection(i[o].substr(8)),this.$=i[o].substr(8);break;case 33:u.addTask(i[o-1],i[o]),this.$="task";break;case 34:this.$=i[o-1],u.setClickEvent(i[o-1],i[o],null);break;case 35:this.$=i[o-2],u.setClickEvent(i[o-2],i[o-1],i[o]);break;case 36:this.$=i[o-2],u.setClickEvent(i[o-2],i[o-1],null),u.setLink(i[o-2],i[o]);break;case 37:this.$=i[o-3],u.setClickEvent(i[o-3],i[o-2],i[o-1]),u.setLink(i[o-3],i[o]);break;case 38:this.$=i[o-2],u.setClickEvent(i[o-2],i[o],null),u.setLink(i[o-2],i[o-1]);break;case 39:this.$=i[o-3],u.setClickEvent(i[o-3],i[o-1],i[o]),u.setLink(i[o-3],i[o-2]);break;case 40:this.$=i[o-1],u.setLink(i[o-1],i[o]);break;case 41:case 47:this.$=i[o-1]+" "+i[o];break;case 42:case 43:case 45:this.$=i[o-2]+" "+i[o-1]+" "+i[o];break;case 44:case 46:this.$=i[o-3]+" "+i[o-2]+" "+i[o-1]+" "+i[o];break}},"anonymous"),table:[{3:1,4:[1,2]},{1:[3]},t(e,[2,2],{5:3}),{6:[1,4],7:5,8:[1,6],9:7,10:[1,8],11:17,12:r,13:n,14:s,15:m,16:f,17:T,18:C,19:18,20:L,21:w,22:P,23:_,24:D,25:G,26:R,27:g,28:M,29:W,30:O,31:H,33:z,35:I,36:x,37:24,38:k,40:E},t(e,[2,7],{1:[2,1]}),t(e,[2,3]),{9:36,11:17,12:r,13:n,14:s,15:m,16:f,17:T,18:C,19:18,20:L,21:w,22:P,23:_,24:D,25:G,26:R,27:g,28:M,29:W,30:O,31:H,33:z,35:I,36:x,37:24,38:k,40:E},t(e,[2,5]),t(e,[2,6]),t(e,[2,17]),t(e,[2,18]),t(e,[2,19]),t(e,[2,20]),t(e,[2,21]),t(e,[2,22]),t(e,[2,23]),t(e,[2,24]),t(e,[2,25]),t(e,[2,26]),t(e,[2,27]),{32:[1,37]},{34:[1,38]},t(e,[2,30]),t(e,[2,31]),t(e,[2,32]),{39:[1,39]},t(e,[2,8]),t(e,[2,9]),t(e,[2,10]),t(e,[2,11]),t(e,[2,12]),t(e,[2,13]),t(e,[2,14]),t(e,[2,15]),t(e,[2,16]),{41:[1,40],43:[1,41]},t(e,[2,4]),t(e,[2,28]),t(e,[2,29]),t(e,[2,33]),t(e,[2,34],{42:[1,42],43:[1,43]}),t(e,[2,40],{41:[1,44]}),t(e,[2,35],{43:[1,45]}),t(e,[2,36]),t(e,[2,38],{42:[1,46]}),t(e,[2,37]),t(e,[2,39])],defaultActions:{},parseError:l(function(a,d){if(d.recoverable)this.trace(a);else{var y=new Error(a);throw y.hash=d,y}},"parseError"),parse:l(function(a){var d=this,y=[0],u=[],S=[null],i=[],Y=this.table,o="",q=0,c=0,$=2,A=1,V=i.slice.call(arguments,1),F=Object.create(this.lexer),B={yy:{}};for(var N in this.yy)Object.prototype.hasOwnProperty.call(this.yy,N)&&(B.yy[N]=this.yy[N]);F.setInput(a,B.yy),B.yy.lexer=F,B.yy.parser=this,typeof F.yylloc>"u"&&(F.yylloc={});var st=F.yylloc;i.push(st);var ot=F.options&&F.options.ranges;typeof B.yy.parseError=="function"?this.parseError=B.yy.parseError:this.parseError=Object.getPrototypeOf(this).parseError;function vt(Q){y.length=y.length-2*Q,S.length=S.length-Q,i.length=i.length-Q}l(vt,"popStack");function dt(){var Q;return Q=u.pop()||F.lex()||A,typeof Q!="number"&&(Q instanceof Array&&(u=Q,Q=u.pop()),Q=d.symbols_[Q]||Q),Q}l(dt,"lex");for(var X,K,Z,ct,J={},at,tt,se,bt;;){if(K=y[y.length-1],this.defaultActions[K]?Z=this.defaultActions[K]:((X===null||typeof X>"u")&&(X=dt()),Z=Y[K]&&Y[K][X]),typeof Z>"u"||!Z.length||!Z[0]){var Lt="";bt=[];for(at in Y[K])this.terminals_[at]&&at>$&&bt.push("'"+this.terminals_[at]+"'");F.showPosition?Lt="Parse error on line "+(q+1)+`:
`+F.showPosition()+`
Expecting `+bt.join(", ")+", got '"+(this.terminals_[X]||X)+"'":Lt="Parse error on line "+(q+1)+": Unexpected "+(X==A?"end of input":"'"+(this.terminals_[X]||X)+"'"),this.parseError(Lt,{text:F.match,token:this.terminals_[X]||X,line:F.yylineno,loc:st,expected:bt})}if(Z[0]instanceof Array&&Z.length>1)throw new Error("Parse Error: multiple actions possible at state: "+K+", token: "+X);switch(Z[0]){case 1:y.push(X),S.push(F.yytext),i.push(F.yylloc),y.push(Z[1]),X=null,c=F.yyleng,o=F.yytext,q=F.yylineno,st=F.yylloc;break;case 2:if(tt=this.productions_[Z[1]][1],J.$=S[S.length-tt],J._$={first_line:i[i.length-(tt||1)].first_line,last_line:i[i.length-1].last_line,first_column:i[i.length-(tt||1)].first_column,last_column:i[i.length-1].last_column},ot&&(J._$.range=[i[i.length-(tt||1)].range[0],i[i.length-1].range[1]]),ct=this.performAction.apply(J,[o,c,q,B.yy,Z[1],S,i].concat(V)),typeof ct<"u")return ct;tt&&(y=y.slice(0,-1*tt*2),S=S.slice(0,-1*tt),i=i.slice(0,-1*tt)),y.push(this.productions_[Z[1]][0]),S.push(J.$),i.push(J._$),se=Y[y[y.length-2]][y[y.length-1]],y.push(se);break;case 3:return!0}}return!0},"parse")},b=(function(){var p={EOF:1,parseError:l(function(d,y){if(this.yy.parser)this.yy.parser.parseError(d,y);else throw new Error(d)},"parseError"),setInput:l(function(a,d){return this.yy=d||this.yy||{},this._input=a,this._more=this._backtrack=this.done=!1,this.yylineno=this.yyleng=0,this.yytext=this.matched=this.match="",this.conditionStack=["INITIAL"],this.yylloc={first_line:1,first_column:0,last_line:1,last_column:0},this.options.ranges&&(this.yylloc.range=[0,0]),this.offset=0,this},"setInput"),input:l(function(){var a=this._input[0];this.yytext+=a,this.yyleng++,this.offset++,this.match+=a,this.matched+=a;var d=a.match(/(?:\r\n?|\n).*/g);return d?(this.yylineno++,this.yylloc.last_line++):this.yylloc.last_column++,this.options.ranges&&this.yylloc.range[1]++,this._input=this._input.slice(1),a},"input"),unput:l(function(a){var d=a.length,y=a.split(/(?:\r\n?|\n)/g);this._input=a+this._input,this.yytext=this.yytext.substr(0,this.yytext.length-d),this.offset-=d;var u=this.match.split(/(?:\r\n?|\n)/g);this.match=this.match.substr(0,this.match.length-1),this.matched=this.matched.substr(0,this.matched.length-1),y.length-1&&(this.yylineno-=y.length-1);var S=this.yylloc.range;return this.yylloc={first_line:this.yylloc.first_line,last_line:this.yylineno+1,first_column:this.yylloc.first_column,last_column:y?(y.length===u.length?this.yylloc.first_column:0)+u[u.length-y.length].length-y[0].length:this.yylloc.first_column-d},this.options.ranges&&(this.yylloc.range=[S[0],S[0]+this.yyleng-d]),this.yyleng=this.yytext.length,this},"unput"),more:l(function(){return this._more=!0,this},"more"),reject:l(function(){if(this.options.backtrack_lexer)this._backtrack=!0;else return this.parseError("Lexical error on line "+(this.yylineno+1)+`. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
`+this.showPosition(),{text:"",token:null,line:this.yylineno});return this},"reject"),less:l(function(a){this.unput(this.match.slice(a))},"less"),pastInput:l(function(){var a=this.matched.substr(0,this.matched.length-this.match.length);return(a.length>20?"...":"")+a.substr(-20).replace(/\n/g,"")},"pastInput"),upcomingInput:l(function(){var a=this.match;return a.length<20&&(a+=this._input.substr(0,20-a.length)),(a.substr(0,20)+(a.length>20?"...":"")).replace(/\n/g,"")},"upcomingInput"),showPosition:l(function(){var a=this.pastInput(),d=new Array(a.length+1).join("-");return a+this.upcomingInput()+`
`+d+"^"},"showPosition"),test_match:l(function(a,d){var y,u,S;if(this.options.backtrack_lexer&&(S={yylineno:this.yylineno,yylloc:{first_line:this.yylloc.first_line,last_line:this.last_line,first_column:this.yylloc.first_column,last_column:this.yylloc.last_column},yytext:this.yytext,match:this.match,matches:this.matches,matched:this.matched,yyleng:this.yyleng,offset:this.offset,_more:this._more,_input:this._input,yy:this.yy,conditionStack:this.conditionStack.slice(0),done:this.done},this.options.ranges&&(S.yylloc.range=this.yylloc.range.slice(0))),u=a[0].match(/(?:\r\n?|\n).*/g),u&&(this.yylineno+=u.length),this.yylloc={first_line:this.yylloc.last_line,last_line:this.yylineno+1,first_column:this.yylloc.last_column,last_column:u?u[u.length-1].length-u[u.length-1].match(/\r?\n?/)[0].length:this.yylloc.last_column+a[0].length},this.yytext+=a[0],this.match+=a[0],this.matches=a,this.yyleng=this.yytext.length,this.options.ranges&&(this.yylloc.range=[this.offset,this.offset+=this.yyleng]),this._more=!1,this._backtrack=!1,this._input=this._input.slice(a[0].length),this.matched+=a[0],y=this.performAction.call(this,this.yy,this,d,this.conditionStack[this.conditionStack.length-1]),this.done&&this._input&&(this.done=!1),y)return y;if(this._backtrack){for(var i in S)this[i]=S[i];return!1}return!1},"test_match"),next:l(function(){if(this.done)return this.EOF;this._input||(this.done=!0);var a,d,y,u;this._more||(this.yytext="",this.match="");for(var S=this._currentRules(),i=0;i<S.length;i++)if(y=this._input.match(this.rules[S[i]]),y&&(!d||y[0].length>d[0].length)){if(d=y,u=i,this.options.backtrack_lexer){if(a=this.test_match(y,S[i]),a!==!1)return a;if(this._backtrack){d=!1;continue}else return!1}else if(!this.options.flex)break}return d?(a=this.test_match(d,S[u]),a!==!1?a:!1):this._input===""?this.EOF:this.parseError("Lexical error on line "+(this.yylineno+1)+`. Unrecognized text.
`+this.showPosition(),{text:"",token:null,line:this.yylineno})},"next"),lex:l(function(){var d=this.next();return d||this.lex()},"lex"),begin:l(function(d){this.conditionStack.push(d)},"begin"),popState:l(function(){var d=this.conditionStack.length-1;return d>0?this.conditionStack.pop():this.conditionStack[0]},"popState"),_currentRules:l(function(){return this.conditionStack.length&&this.conditionStack[this.conditionStack.length-1]?this.conditions[this.conditionStack[this.conditionStack.length-1]].rules:this.conditions.INITIAL.rules},"_currentRules"),topState:l(function(d){return d=this.conditionStack.length-1-Math.abs(d||0),d>=0?this.conditionStack[d]:"INITIAL"},"topState"),pushState:l(function(d){this.begin(d)},"pushState"),stateStackSize:l(function(){return this.conditionStack.length},"stateStackSize"),options:{"case-insensitive":!0},performAction:l(function(d,y,u,S){switch(u){case 0:return this.begin("open_directive"),"open_directive";case 1:return this.begin("acc_title"),31;case 2:return this.popState(),"acc_title_value";case 3:return this.begin("acc_descr"),33;case 4:return this.popState(),"acc_descr_value";case 5:this.begin("acc_descr_multiline");break;case 6:this.popState();break;case 7:return"acc_descr_multiline_value";case 8:break;case 9:break;case 10:break;case 11:return 10;case 12:break;case 13:break;case 14:this.begin("href");break;case 15:this.popState();break;case 16:return 43;case 17:this.begin("callbackname");break;case 18:this.popState();break;case 19:this.popState(),this.begin("callbackargs");break;case 20:return 41;case 21:this.popState();break;case 22:return 42;case 23:this.begin("click");break;case 24:this.popState();break;case 25:return 40;case 26:return 4;case 27:return 22;case 28:return 23;case 29:return 24;case 30:return 25;case 31:return 26;case 32:return 28;case 33:return 27;case 34:return 29;case 35:return 12;case 36:return 13;case 37:return 14;case 38:return 15;case 39:return 16;case 40:return 17;case 41:return 18;case 42:return 20;case 43:return 21;case 44:return"date";case 45:return 30;case 46:return"accDescription";case 47:return 36;case 48:return 38;case 49:return 39;case 50:return":";case 51:return 6;case 52:return"INVALID"}},"anonymous"),rules:[/^(?:%%\{)/i,/^(?:accTitle\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*\{\s*)/i,/^(?:[\}])/i,/^(?:[^\}]*)/i,/^(?:%%(?!\{)*[^\n]*)/i,/^(?:[^\}]%%*[^\n]*)/i,/^(?:%%*[^\n]*[\n]*)/i,/^(?:[\n]+)/i,/^(?:\s+)/i,/^(?:%[^\n]*)/i,/^(?:href[\s]+["])/i,/^(?:["])/i,/^(?:[^"]*)/i,/^(?:call[\s]+)/i,/^(?:\([\s]*\))/i,/^(?:\()/i,/^(?:[^(]*)/i,/^(?:\))/i,/^(?:[^)]*)/i,/^(?:click[\s]+)/i,/^(?:[\s\n])/i,/^(?:[^\s\n]*)/i,/^(?:gantt\b)/i,/^(?:dateFormat\s[^#\n;]+)/i,/^(?:inclusiveEndDates\b)/i,/^(?:topAxis\b)/i,/^(?:axisFormat\s[^#\n;]+)/i,/^(?:tickInterval\s[^#\n;]+)/i,/^(?:includes\s[^#\n;]+)/i,/^(?:excludes\s[^#\n;]+)/i,/^(?:todayMarker\s[^\n;]+)/i,/^(?:weekday\s+monday\b)/i,/^(?:weekday\s+tuesday\b)/i,/^(?:weekday\s+wednesday\b)/i,/^(?:weekday\s+thursday\b)/i,/^(?:weekday\s+friday\b)/i,/^(?:weekday\s+saturday\b)/i,/^(?:weekday\s+sunday\b)/i,/^(?:weekend\s+friday\b)/i,/^(?:weekend\s+saturday\b)/i,/^(?:\d\d\d\d-\d\d-\d\d\b)/i,/^(?:title\s[^\n]+)/i,/^(?:accDescription\s[^#\n;]+)/i,/^(?:section\s[^\n]+)/i,/^(?:[^:\n]+)/i,/^(?::[^#\n;]+)/i,/^(?::)/i,/^(?:$)/i,/^(?:.)/i],conditions:{acc_descr_multiline:{rules:[6,7],inclusive:!1},acc_descr:{rules:[4],inclusive:!1},acc_title:{rules:[2],inclusive:!1},callbackargs:{rules:[21,22],inclusive:!1},callbackname:{rules:[18,19,20],inclusive:!1},href:{rules:[15,16],inclusive:!1},click:{rules:[24,25],inclusive:!1},INITIAL:{rules:[0,1,3,5,8,9,10,11,12,13,14,17,23,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52],inclusive:!0}}};return p})();h.lexer=b;function v(){this.yy={}}return l(v,"Parser"),v.prototype=h,h.Parser=v,new v})();qt.parser=qt;var Hr=qt;U.extend(Ir);U.extend(Fr);U.extend(Pr);var pe={friday:5,saturday:6},et="",Ut="",Zt=void 0,Qt="",yt=[],gt=[],Kt=new Map,Jt=[],$t=[],pt="",te="",Ae=["active","done","crit","milestone","vert"],ee=[],ft="",xt=!1,re=!1,ne="sunday",At="saturday",Gt=0,Br=l(function(){Jt=[],$t=[],pt="",ee=[],Et=0,jt=void 0,It=void 0,j=[],et="",Ut="",te="",Zt=void 0,Qt="",yt=[],gt=[],xt=!1,re=!1,Gt=0,Kt=new Map,ft="",ur(),ne="sunday",At="saturday"},"clear"),qr=l(function(t){ft=t},"setDiagramId"),Gr=l(function(t){Ut=t},"setAxisFormat"),Xr=l(function(){return Ut},"getAxisFormat"),jr=l(function(t){Zt=t},"setTickInterval"),Ur=l(function(){return Zt},"getTickInterval"),Zr=l(function(t){Qt=t},"setTodayMarker"),Qr=l(function(){return Qt},"getTodayMarker"),Kr=l(function(t){et=t},"setDateFormat"),Jr=l(function(){xt=!0},"enableInclusiveEndDates"),tn=l(function(){return xt},"endDatesAreInclusive"),en=l(function(){re=!0},"enableTopAxis"),rn=l(function(){return re},"topAxisEnabled"),nn=l(function(t){te=t},"setDisplayMode"),sn=l(function(){return te},"getDisplayMode"),an=l(function(){return et},"getDateFormat"),Fe=l((t,e)=>{const r=e.toLowerCase().split(/[\s,]+/).filter(n=>n!=="");return[...new Set([...t,...r])]},"mergeTokens"),on=l(function(t){yt=Fe(yt,t)},"setIncludes"),cn=l(function(){return yt},"getIncludes"),ln=l(function(t){gt=Fe(gt,t)},"setExcludes"),un=l(function(){return gt},"getExcludes"),dn=l(function(){return Kt},"getLinks"),fn=l(function(t){pt=t,Jt.push(t)},"addSection"),hn=l(function(){return Jt},"getSections"),mn=l(function(){let t=ve();const e=10;let r=0;for(;!t&&r<e;)t=ve(),r++;return $t=j,$t},"getTasks"),Le=l(function(t,e,r,n){const s=t.format(e.trim()),m=t.format("YYYY-MM-DD");return n.includes(s)||n.includes(m)?!1:r.includes("weekends")&&(t.isoWeekday()===pe[At]||t.isoWeekday()===pe[At]+1)||r.includes(t.format("dddd").toLowerCase())?!0:r.includes(s)||r.includes(m)},"isInvalidDate"),kn=l(function(t){ne=t},"setWeekday"),yn=l(function(){return ne},"getWeekday"),gn=l(function(t){At=t},"setWeekend"),Oe=l(function(t,e,r,n){if(!r.length||t.manualEndTime)return;let s;t.startTime instanceof Date?s=U(t.startTime):s=U(t.startTime,e,!0),s=s.add(1,"d");let m;t.endTime instanceof Date?m=U(t.endTime):m=U(t.endTime,e,!0);const[f,T]=pn(s,m,e,r,n);t.endTime=f.toDate(),t.renderEndTime=T},"checkTaskDates"),pn=l(function(t,e,r,n,s){let m=!1,f=null;const T=e.add(1e4,"d");for(;t<=e;){if(m||(f=e.toDate()),m=Le(t,r,n,s),m&&(e=e.add(1,"d"),e>T))throw new Error("Failed to find a valid date that was not excluded by `excludes` after 10,000 iterations.");t=t.add(1,"d")}return[e,f]},"fixTaskDates"),Xt=l(function(t,e,r){if(r=r.trim(),l(T=>{const C=T.trim();return C==="x"||C==="X"},"isTimestampFormat")(e)&&/^\d+$/.test(r))return new Date(Number(r));const m=/^after\s+(?<ids>[\d\w- ]+)/.exec(r);if(m!==null){let T=null;for(const L of m.groups.ids.split(" ")){let w=ut(L);w!==void 0&&(!T||w.endTime>T.endTime)&&(T=w)}if(T)return T.endTime;const C=new Date;return C.setHours(0,0,0,0),C}let f=U(r,e.trim(),!0);if(f.isValid())return f.toDate();{lt.debug("Invalid date:"+r),lt.debug("With date format:"+e.trim());const T=new Date(r);if(T===void 0||isNaN(T.getTime())||T.getFullYear()<-1e4||T.getFullYear()>1e4)throw new Error("Invalid date:"+r);return T}},"getStartDate"),We=l(function(t){const e=/^(\d+(?:\.\d+)?)([Mdhmswy]|ms)$/.exec(t.trim());return e!==null?[Number.parseFloat(e[1]),e[2]]:[NaN,"ms"]},"parseDuration"),Pe=l(function(t,e,r,n=!1){r=r.trim();const m=/^until\s+(?<ids>[\d\w- ]+)/.exec(r);if(m!==null){let w=null;for(const _ of m.groups.ids.split(" ")){let D=ut(_);D!==void 0&&(!w||D.startTime<w.startTime)&&(w=D)}if(w)return w.startTime;const P=new Date;return P.setHours(0,0,0,0),P}let f=U(r,e.trim(),!0);if(f.isValid())return n&&(f=f.add(1,"d")),f.toDate();let T=U(t);const[C,L]=We(r);if(!Number.isNaN(C)){const w=T.add(C,L);w.isValid()&&(T=w)}return T.toDate()},"getEndDate"),Et=0,kt=l(function(t){return t===void 0?(Et=Et+1,"task"+Et):t},"parseId"),vn=l(function(t,e){let r;e.substr(0,1)===":"?r=e.substr(1,e.length):r=e;const n=r.split(","),s={};ie(n,s,Ae);for(let f=0;f<n.length;f++)n[f]=n[f].trim();let m="";switch(n.length){case 1:s.id=kt(),s.startTime=t.endTime,m=n[0];break;case 2:s.id=kt(),s.startTime=Xt(void 0,et,n[0]),m=n[1];break;case 3:s.id=kt(n[0]),s.startTime=Xt(void 0,et,n[1]),m=n[2];break}return m&&(s.endTime=Pe(s.startTime,et,m,xt),s.manualEndTime=U(m,"YYYY-MM-DD",!0).isValid(),Oe(s,et,gt,yt)),s},"compileData"),xn=l(function(t,e){let r;e.substr(0,1)===":"?r=e.substr(1,e.length):r=e;const n=r.split(","),s={};ie(n,s,Ae);for(let m=0;m<n.length;m++)n[m]=n[m].trim();switch(n.length){case 1:s.id=kt(),s.startTime={type:"prevTaskEnd",id:t},s.endTime={data:n[0]};break;case 2:s.id=kt(),s.startTime={type:"getStartDate",startData:n[0]},s.endTime={data:n[1]};break;case 3:s.id=kt(n[0]),s.startTime={type:"getStartDate",startData:n[1]},s.endTime={data:n[2]};break}return s},"parseData"),jt,It,j=[],Ne={},bn=l(function(t,e){const r={section:pt,type:pt,processed:!1,manualEndTime:!1,renderEndTime:null,raw:{data:e},task:t,classes:[]},n=xn(It,e);r.raw.startTime=n.startTime,r.raw.endTime=n.endTime,r.id=n.id,r.prevTaskId=It,r.active=n.active,r.done=n.done,r.crit=n.crit,r.milestone=n.milestone,r.vert=n.vert,r.vert?r.order=-1:(r.order=Gt,Gt++);const s=j.push(r);It=r.id,Ne[r.id]=s-1},"addTask"),ut=l(function(t){const e=Ne[t];return j[e]},"findTaskById"),Tn=l(function(t,e){const r={section:pt,type:pt,description:t,task:t,classes:[]},n=vn(jt,e);r.startTime=n.startTime,r.endTime=n.endTime,r.id=n.id,r.active=n.active,r.done=n.done,r.crit=n.crit,r.milestone=n.milestone,r.vert=n.vert,jt=r,$t.push(r)},"addTaskOrg"),ve=l(function(){const t=l(function(r){const n=j[r];let s="";switch(j[r].raw.startTime.type){case"prevTaskEnd":{const m=ut(n.prevTaskId);n.startTime=m.endTime;break}case"getStartDate":s=Xt(void 0,et,j[r].raw.startTime.startData),s&&(j[r].startTime=s);break}return j[r].startTime&&(j[r].endTime=Pe(j[r].startTime,et,j[r].raw.endTime.data,xt),j[r].endTime&&(j[r].processed=!0,j[r].manualEndTime=U(j[r].raw.endTime.data,"YYYY-MM-DD",!0).isValid(),Oe(j[r],et,gt,yt))),j[r].processed},"compileTask");let e=!0;for(const[r,n]of j.entries())t(r),e=e&&n.processed;return e},"compileTasks"),wn=l(function(t,e){let r=e;ht().securityLevel!=="loose"&&(r=lr.sanitizeUrl(e)),t.split(",").forEach(function(n){ut(n)!==void 0&&(ze(n,()=>{window.open(r,"_self")}),Kt.set(n,r))}),Ve(t,"clickable")},"setLink"),Ve=l(function(t,e){t.split(",").forEach(function(r){let n=ut(r);n!==void 0&&n.classes.push(e)})},"setClass"),_n=l(function(t,e,r){if(ht().securityLevel!=="loose"||e===void 0)return;let n=[];if(typeof r=="string"){n=r.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);for(let m=0;m<n.length;m++){let f=n[m].trim();f.startsWith('"')&&f.endsWith('"')&&(f=f.substr(1,f.length-2)),n[m]=f}}n.length===0&&n.push(t),ut(t)!==void 0&&ze(t,()=>{dr.runFunc(e,...n)})},"setClickFun"),ze=l(function(t,e){ee.push(function(){const r=ft?`${ft}-${t}`:t,n=document.querySelector(`[id="${r}"]`);n!==null&&n.addEventListener("click",function(){e()})},function(){const r=ft?`${ft}-${t}`:t,n=document.querySelector(`[id="${r}-text"]`);n!==null&&n.addEventListener("click",function(){e()})})},"pushFun"),Dn=l(function(t,e,r){t.split(",").forEach(function(n){_n(n,e,r)}),Ve(t,"clickable")},"setClickEvent"),Sn=l(function(t){ee.forEach(function(e){e(t)})},"bindFunctions"),Cn={getConfig:l(()=>ht().gantt,"getConfig"),clear:Br,setDateFormat:Kr,getDateFormat:an,enableInclusiveEndDates:Jr,endDatesAreInclusive:tn,enableTopAxis:en,topAxisEnabled:rn,setAxisFormat:Gr,getAxisFormat:Xr,setTickInterval:jr,getTickInterval:Ur,setTodayMarker:Zr,getTodayMarker:Qr,setAccTitle:Ue,getAccTitle:je,setDiagramTitle:Xe,getDiagramTitle:Ge,setDiagramId:qr,setDisplayMode:nn,getDisplayMode:sn,setAccDescription:qe,getAccDescription:Be,addSection:fn,getSections:hn,getTasks:mn,addTask:bn,findTaskById:ut,addTaskOrg:Tn,setIncludes:on,getIncludes:cn,setExcludes:ln,getExcludes:un,setClickEvent:Dn,setLink:wn,getLinks:dn,bindFunctions:Sn,parseDuration:We,isInvalidDate:Le,setWeekday:kn,getWeekday:yn,setWeekend:gn};function ie(t,e,r){let n=!0;for(;n;)n=!1,r.forEach(function(s){const m="^\\s*"+s+"\\s*$",f=new RegExp(m);t[0].match(f)&&(e[s]=!0,t.shift(1),n=!0)})}l(ie,"getTaskTags");U.extend(Rr);var Mn=l(function(){lt.debug("Something is calling, setConf, remove the call")},"setConf"),xe={monday:or,tuesday:ar,wednesday:sr,thursday:ir,friday:nr,saturday:rr,sunday:er},En=l((t,e)=>{let r=[...t].map(()=>-1/0),n=[...t].sort((m,f)=>m.startTime-f.startTime||m.order-f.order),s=0;for(const m of n)for(let f=0;f<r.length;f++)if(m.startTime>=r[f]){r[f]=m.endTime,m.order=f+e,f>s&&(s=f);break}return s},"getMaxIntersections"),nt,Rt=1e4,In=l(function(t,e,r,n){const s=ht().gantt;n.db.setDiagramId(e);const m=ht().securityLevel;let f;m==="sandbox"&&(f=Tt("#i"+e));const T=m==="sandbox"?Tt(f.nodes()[0].contentDocument.body):Tt("body"),C=m==="sandbox"?f.nodes()[0].contentDocument:document,L=C.getElementById(e);nt=L.parentElement.offsetWidth,nt===void 0&&(nt=1200),s.useWidth!==void 0&&(nt=s.useWidth);const w=n.db.getTasks(),P=w.filter(h=>!h.vert);let _=[];for(const h of P)_.push(h.type);_=E(_);const D={};let G=2*s.topPadding;if(n.db.getDisplayMode()==="compact"||s.displayMode==="compact"){const h={};for(const v of P)h[v.section]===void 0?h[v.section]=[v]:h[v.section].push(v);let b=0;for(const v of Object.keys(h)){const p=En(h[v],b)+1;b+=p,G+=p*(s.barHeight+s.barGap),D[v]=p}}else{G+=P.length*(s.barHeight+s.barGap);for(const h of _)D[h]=P.filter(b=>b.type===h).length}L.setAttribute("viewBox","0 0 "+nt+" "+G);const R=T.select(`[id="${e}"]`),g=Ze().domain([Qe(w,function(h){return h.startTime}),Ke(w,function(h){return h.endTime})]).rangeRound([0,nt-s.leftPadding-s.rightPadding]);function M(h,b){const v=h.startTime,p=b.startTime;let a=0;return v>p?a=1:v<p&&(a=-1),a}l(M,"taskCompare"),w.sort(M),W(w,nt,G),Je(R,G,nt,s.useMaxWidth),R.append("text").text(n.db.getDiagramTitle()).attr("x",nt/2).attr("y",s.titleTopMargin).attr("class","titleText");function W(h,b,v){const p=s.barHeight,a=p+s.barGap,d=s.topPadding,y=s.leftPadding,u=tr().domain([0,_.length]).range(["#00B9FA","#F95002"]).interpolate(Sr);H(a,d,y,b,v,h,n.db.getExcludes(),n.db.getIncludes()),I(y,d,b,v),O(h,a,d,y,p,u,b),x(a,d),k(y,d,b,v)}l(W,"makeGantt");function O(h,b,v,p,a,d,y){h.sort((c,$)=>c.vert===$.vert?0:c.vert?1:-1);const u=h.filter(c=>!c.vert),i=[...new Set(u.map(c=>c.order))].map(c=>u.find($=>$.order===c));R.append("g").selectAll("rect").data(i).enter().append("rect").attr("x",0).attr("y",function(c,$){return $=c.order,$*b+v-2}).attr("width",function(){return y-s.rightPadding/2}).attr("height",b).attr("class",function(c){for(const[$,A]of _.entries())if(c.type===A)return"section section"+$%s.numberSectionStyles;return"section section0"}).enter();const Y=R.append("g").selectAll("rect").data(h).enter(),o=n.db.getLinks();if(Y.append("rect").attr("id",function(c){return e+"-"+c.id}).attr("rx",3).attr("ry",3).attr("x",function(c){return c.milestone?g(c.startTime)+p+.5*(g(c.endTime)-g(c.startTime))-.5*a:g(c.startTime)+p}).attr("y",function(c,$){return $=c.order,c.vert?s.gridLineStartPadding:$*b+v}).attr("width",function(c){return c.milestone?a:c.vert?.08*a:g(c.renderEndTime||c.endTime)-g(c.startTime)}).attr("height",function(c){return c.vert?u.length*(s.barHeight+s.barGap)+s.barHeight*2:a}).attr("transform-origin",function(c,$){return $=c.order,(g(c.startTime)+p+.5*(g(c.endTime)-g(c.startTime))).toString()+"px "+($*b+v+.5*a).toString()+"px"}).attr("class",function(c){const $="task";let A="";c.classes.length>0&&(A=c.classes.join(" "));let V=0;for(const[B,N]of _.entries())c.type===N&&(V=B%s.numberSectionStyles);let F="";return c.active?c.crit?F+=" activeCrit":F=" active":c.done?c.crit?F=" doneCrit":F=" done":c.crit&&(F+=" crit"),F.length===0&&(F=" task"),c.milestone&&(F=" milestone "+F),c.vert&&(F=" vert "+F),F+=V,F+=" "+A,$+F}),Y.append("text").attr("id",function(c){return e+"-"+c.id+"-text"}).text(function(c){return c.task}).attr("font-size",s.fontSize).attr("x",function(c){let $=g(c.startTime),A=g(c.renderEndTime||c.endTime);if(c.milestone&&($+=.5*(g(c.endTime)-g(c.startTime))-.5*a,A=$+a),c.vert)return g(c.startTime)+p;const V=this.getBBox().width;return V>A-$?A+V+1.5*s.leftPadding>y?$+p-5:A+p+5:(A-$)/2+$+p}).attr("y",function(c,$){return c.vert?s.gridLineStartPadding+u.length*(s.barHeight+s.barGap)+60:($=c.order,$*b+s.barHeight/2+(s.fontSize/2-2)+v)}).attr("text-height",a).attr("class",function(c){const $=g(c.startTime);let A=g(c.endTime);c.milestone&&(A=$+a);const V=this.getBBox().width;let F="";c.classes.length>0&&(F=c.classes.join(" "));let B=0;for(const[st,ot]of _.entries())c.type===ot&&(B=st%s.numberSectionStyles);let N="";return c.active&&(c.crit?N="activeCritText"+B:N="activeText"+B),c.done?c.crit?N=N+" doneCritText"+B:N=N+" doneText"+B:c.crit&&(N=N+" critText"+B),c.milestone&&(N+=" milestoneText"),c.vert&&(N+=" vertText"),V>A-$?A+V+1.5*s.leftPadding>y?F+" taskTextOutsideLeft taskTextOutside"+B+" "+N:F+" taskTextOutsideRight taskTextOutside"+B+" "+N+" width-"+V:F+" taskText taskText"+B+" "+N+" width-"+V}),ht().securityLevel==="sandbox"){let c;c=Tt("#i"+e);const $=c.nodes()[0].contentDocument;Y.filter(function(A){return o.has(A.id)}).each(function(A){var V=$.querySelector("#"+CSS.escape(e+"-"+A.id)),F=$.querySelector("#"+CSS.escape(e+"-"+A.id+"-text"));const B=V.parentNode;var N=$.createElement("a");N.setAttribute("xlink:href",o.get(A.id)),N.setAttribute("target","_top"),B.appendChild(N),N.appendChild(V),N.appendChild(F)})}}l(O,"drawRects");function H(h,b,v,p,a,d,y,u){if(y.length===0&&u.length===0)return;let S,i;for(const{startTime:A,endTime:V}of d)(S===void 0||A<S)&&(S=A),(i===void 0||V>i)&&(i=V);if(!S||!i)return;if(U(i).diff(U(S),"year")>5){lt.warn("The difference between the min and max time is more than 5 years. This will cause performance issues. Skipping drawing exclude days.");return}const Y=n.db.getDateFormat(),o=[];let q=null,c=U(S);for(;c.valueOf()<=i;)n.db.isInvalidDate(c,Y,y,u)?q?q.end=c:q={start:c,end:c}:q&&(o.push(q),q=null),c=c.add(1,"d");R.append("g").selectAll("rect").data(o).enter().append("rect").attr("id",A=>e+"-exclude-"+A.start.format("YYYY-MM-DD")).attr("x",A=>g(A.start.startOf("day"))+v).attr("y",s.gridLineStartPadding).attr("width",A=>g(A.end.endOf("day"))-g(A.start.startOf("day"))).attr("height",a-b-s.gridLineStartPadding).attr("transform-origin",function(A,V){return(g(A.start)+v+.5*(g(A.end)-g(A.start))).toString()+"px "+(V*h+.5*a).toString()+"px"}).attr("class","exclude-range")}l(H,"drawExcludeDays");function z(h,b,v,p){if(v<=0||h>b)return 1/0;const a=b-h,d=U.duration({[p??"day"]:v}).asMilliseconds();return d<=0?1/0:Math.ceil(a/d)}l(z,"getEstimatedTickCount");function I(h,b,v,p){const a=n.db.getDateFormat(),d=n.db.getAxisFormat();let y;d?y=d:a==="D"?y="%d":y=s.axisFormat??"%Y-%m-%d";let u=vr(g).tickSize(-p+b+s.gridLineStartPadding).tickFormat(ae(y));const i=/^([1-9]\d*)(millisecond|second|minute|hour|day|week|month)$/.exec(n.db.getTickInterval()||s.tickInterval);if(i!==null){const Y=parseInt(i[1],10);if(isNaN(Y)||Y<=0)lt.warn(`Invalid tick interval value: "${i[1]}". Skipping custom tick interval.`);else{const o=i[2],q=n.db.getWeekday()||s.weekday,c=g.domain(),$=c[0],A=c[1],V=z($,A,Y,o);if(V>Rt)lt.warn(`The tick interval "${Y}${o}" would generate ${V} ticks, which exceeds the maximum allowed (${Rt}). This may indicate an invalid date or time range. Skipping custom tick interval.`);else switch(o){case"millisecond":u.ticks(fe.every(Y));break;case"second":u.ticks(de.every(Y));break;case"minute":u.ticks(ue.every(Y));break;case"hour":u.ticks(le.every(Y));break;case"day":u.ticks(ce.every(Y));break;case"week":u.ticks(xe[q].every(Y));break;case"month":u.ticks(oe.every(Y));break}}}if(R.append("g").attr("class","grid").attr("transform","translate("+h+", "+(p-50)+")").call(u).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10).attr("dy","1em"),n.db.topAxisEnabled()||s.topAxis){let Y=pr(g).tickSize(-p+b+s.gridLineStartPadding).tickFormat(ae(y));if(i!==null){const o=parseInt(i[1],10);if(isNaN(o)||o<=0)lt.warn(`Invalid tick interval value: "${i[1]}". Skipping custom tick interval.`);else{const q=i[2],c=n.db.getWeekday()||s.weekday,$=g.domain(),A=$[0],V=$[1];if(z(A,V,o,q)<=Rt)switch(q){case"millisecond":Y.ticks(fe.every(o));break;case"second":Y.ticks(de.every(o));break;case"minute":Y.ticks(ue.every(o));break;case"hour":Y.ticks(le.every(o));break;case"day":Y.ticks(ce.every(o));break;case"week":Y.ticks(xe[c].every(o));break;case"month":Y.ticks(oe.every(o));break}}}R.append("g").attr("class","grid").attr("transform","translate("+h+", "+b+")").call(Y).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10)}}l(I,"makeGrid");function x(h,b){let v=0;const p=Object.keys(D).map(a=>[a,D[a]]);R.append("g").selectAll("text").data(p).enter().append(function(a){const d=a[0].split(cr.lineBreakRegex),y=-(d.length-1)/2,u=C.createElementNS("http://www.w3.org/2000/svg","text");u.setAttribute("dy",y+"em");for(const[S,i]of d.entries()){const Y=C.createElementNS("http://www.w3.org/2000/svg","tspan");Y.setAttribute("alignment-baseline","central"),Y.setAttribute("x","10"),S>0&&Y.setAttribute("dy","1em"),Y.textContent=i,u.appendChild(Y)}return u}).attr("x",10).attr("y",function(a,d){if(d>0)for(let y=0;y<d;y++)return v+=p[d-1][1],a[1]*h/2+v*h+b;else return a[1]*h/2+b}).attr("font-size",s.sectionFontSize).attr("class",function(a){for(const[d,y]of _.entries())if(a[0]===y)return"sectionTitle sectionTitle"+d%s.numberSectionStyles;return"sectionTitle"})}l(x,"vertLabels");function k(h,b,v,p){const a=n.db.getTodayMarker();if(a==="off")return;const d=R.append("g").attr("class","today"),y=new Date,u=d.append("line");u.attr("x1",g(y)+h).attr("x2",g(y)+h).attr("y1",s.titleTopMargin).attr("y2",p-s.titleTopMargin).attr("class","today"),a!==""&&u.attr("style",a.replace(/,/g,";"))}l(k,"drawToday");function E(h){const b={},v=[];for(let p=0,a=h.length;p<a;++p)Object.prototype.hasOwnProperty.call(b,h[p])||(b[h[p]]=!0,v.push(h[p]));return v}l(E,"checkUnique")},"draw"),Yn={setConf:Mn,draw:In},$n=l(t=>`
  .mermaid-main-font {
        font-family: ${t.fontFamily};
  }

  .exclude-range {
    fill: ${t.excludeBkgColor};
  }

  .section {
    stroke: none;
    opacity: 0.2;
  }

  .section0 {
    fill: ${t.sectionBkgColor};
  }

  .section2 {
    fill: ${t.sectionBkgColor2};
  }

  .section1,
  .section3 {
    fill: ${t.altSectionBkgColor};
    opacity: 0.2;
  }

  .sectionTitle0 {
    fill: ${t.titleColor};
  }

  .sectionTitle1 {
    fill: ${t.titleColor};
  }

  .sectionTitle2 {
    fill: ${t.titleColor};
  }

  .sectionTitle3 {
    fill: ${t.titleColor};
  }

  .sectionTitle {
    text-anchor: start;
    font-family: ${t.fontFamily};
  }


  /* Grid and axis */

  .grid .tick {
    stroke: ${t.gridColor};
    opacity: 0.8;
    shape-rendering: crispEdges;
  }

  .grid .tick text {
    font-family: ${t.fontFamily};
    fill: ${t.textColor};
  }

  .grid path {
    stroke-width: 0;
  }


  /* Today line */

  .today {
    fill: none;
    stroke: ${t.todayLineColor};
    stroke-width: 2px;
  }


  /* Task styling */

  /* Default task */

  .task {
    stroke-width: 2;
  }

  .taskText {
    text-anchor: middle;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideRight {
    fill: ${t.taskTextDarkColor};
    text-anchor: start;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideLeft {
    fill: ${t.taskTextDarkColor};
    text-anchor: end;
  }


  /* Special case clickable */

  .task.clickable {
    cursor: pointer;
  }

  .taskText.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideLeft.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideRight.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }


  /* Specific task settings for the sections*/

  .taskText0,
  .taskText1,
  .taskText2,
  .taskText3 {
    fill: ${t.taskTextColor};
  }

  .task0,
  .task1,
  .task2,
  .task3 {
    fill: ${t.taskBkgColor};
    stroke: ${t.taskBorderColor};
  }

  .taskTextOutside0,
  .taskTextOutside2
  {
    fill: ${t.taskTextOutsideColor};
  }

  .taskTextOutside1,
  .taskTextOutside3 {
    fill: ${t.taskTextOutsideColor};
  }


  /* Active task */

  .active0,
  .active1,
  .active2,
  .active3 {
    fill: ${t.activeTaskBkgColor};
    stroke: ${t.activeTaskBorderColor};
  }

  .activeText0,
  .activeText1,
  .activeText2,
  .activeText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Completed task */

  .done0,
  .done1,
  .done2,
  .done3 {
    stroke: ${t.doneTaskBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
  }

  .doneText0,
  .doneText1,
  .doneText2,
  .doneText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  /* Done task text displayed outside the bar sits against the diagram background,
     not against the done-task bar, so it must use the outside/contrast color. */
  .doneText0.taskTextOutsideLeft,
  .doneText0.taskTextOutsideRight,
  .doneText1.taskTextOutsideLeft,
  .doneText1.taskTextOutsideRight,
  .doneText2.taskTextOutsideLeft,
  .doneText2.taskTextOutsideRight,
  .doneText3.taskTextOutsideLeft,
  .doneText3.taskTextOutsideRight {
    fill: ${t.taskTextOutsideColor} !important;
  }


  /* Tasks on the critical line */

  .crit0,
  .crit1,
  .crit2,
  .crit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.critBkgColor};
    stroke-width: 2;
  }

  .activeCrit0,
  .activeCrit1,
  .activeCrit2,
  .activeCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.activeTaskBkgColor};
    stroke-width: 2;
  }

  .doneCrit0,
  .doneCrit1,
  .doneCrit2,
  .doneCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
    cursor: pointer;
    shape-rendering: crispEdges;
  }

  .milestone {
    transform: rotate(45deg) scale(0.8,0.8);
  }

  .milestoneText {
    font-style: italic;
  }
  .doneCritText0,
  .doneCritText1,
  .doneCritText2,
  .doneCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  /* Done-crit task text outside the bar — same reasoning as doneText above. */
  .doneCritText0.taskTextOutsideLeft,
  .doneCritText0.taskTextOutsideRight,
  .doneCritText1.taskTextOutsideLeft,
  .doneCritText1.taskTextOutsideRight,
  .doneCritText2.taskTextOutsideLeft,
  .doneCritText2.taskTextOutsideRight,
  .doneCritText3.taskTextOutsideLeft,
  .doneCritText3.taskTextOutsideRight {
    fill: ${t.taskTextOutsideColor} !important;
  }

  .vert {
    stroke: ${t.vertLineColor};
  }

  .vertText {
    font-size: 15px;
    text-anchor: middle;
    fill: ${t.vertLineColor} !important;
  }

  .activeCritText0,
  .activeCritText1,
  .activeCritText2,
  .activeCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .titleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.titleColor||t.textColor};
    font-family: ${t.fontFamily};
  }
`,"getStyles"),An=$n,Ln={parser:Hr,db:Cn,renderer:Yn,styles:An};export{Ln as diagram};
