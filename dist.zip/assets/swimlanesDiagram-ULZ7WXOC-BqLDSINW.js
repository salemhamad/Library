import{c as e,s as r}from"./flowDiagram-UKHOOZJN-DFiMzAL2.js";import{_ as a}from"./index-C45OdmOW.js";import"./chunk-5VM5RSS4-Dn6XZuZa.js";import"./chunk-XXDRQBXY-uQqTXRg6.js";import"./chunk-KBJHAD2P-CKUG2fU0.js";import"./chunk-2GRJ4B5K-OaNk8NU3.js";import"./channel-DD_39F_0.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
