import{c as e,s as r}from"./flowDiagram-UKHOOZJN-R23VrYuI.js";import{_ as a}from"./index-CwhCO1A9.js";import"./chunk-5VM5RSS4-DJNkBTOk.js";import"./chunk-XXDRQBXY-DvBfj-_w.js";import"./chunk-KBJHAD2P-D13q_vO2.js";import"./chunk-2GRJ4B5K-Ctu1oYkj.js";import"./channel-lTjF2vq2.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
