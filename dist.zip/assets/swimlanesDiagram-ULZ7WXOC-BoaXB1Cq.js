import{c as e,s as r}from"./flowDiagram-UKHOOZJN-DcSYTMOB.js";import{_ as a}from"./index-BhxSSt6R.js";import"./chunk-5VM5RSS4-C6PT-GzP.js";import"./chunk-XXDRQBXY-Dh8hgPYN.js";import"./chunk-KBJHAD2P-CgpbCYWo.js";import"./chunk-2GRJ4B5K-DqQIjcI3.js";import"./channel-kMuQH96B.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
