const RESEND_API_KEY = 're_12qvPYvo_3c74oc4v9jCprgyYyfGBpDv7';
const FROM_EMAIL = 'Infinite Notes <onboarding@resend.dev>';

async function sendEmail(to, subject, html) {
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: FROM_EMAIL, to: [to], subject, html }),
  });
  const data = await response.json();
  return { ok: response.ok, data };
}

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/email/send-verification' && request.method === 'POST') {
      try {
        const { to, code } = await request.json();
        if (!to || !code) return jsonResponse({ success: false, error: 'Missing to or code' }, 400);
        const html = `<div dir="rtl" style="font-family:Arial,sans-serif;max-width:500px;margin:auto;background:#1a1a2e;color:#fff;padding:40px;border-radius:16px;"><h1 style="text-align:center;color:#4fc3f7;">📝 Infinite Notes</h1><h2 style="text-align:center;color:#e0e0e0;">رمز تفعيل حسابك</h2><div style="background:#0f3460;padding:24px;border-radius:12px;text-align:center;margin:24px 0;"><span style="font-size:36px;letter-spacing:12px;font-weight:bold;color:#4fc3f7;">${code}</span></div><p style="text-align:center;color:#999;">هذا الرمز صالح لمدة 10 دقائق</p></div>`;
        const result = await sendEmail(to, `رمز التفعيل: ${code} - Infinite Notes`, html);
        if (result.ok) return jsonResponse({ success: true });
        else return jsonResponse({ success: false, error: result.data }, 500);
      } catch (err) {
        return jsonResponse({ success: false, error: err.message }, 500);
      }
    }

    if (url.pathname === '/api/email/send-reset' && request.method === 'POST') {
      try {
        const { to, code } = await request.json();
        if (!to || !code) return jsonResponse({ success: false, error: 'Missing to or code' }, 400);
        const html = `<div dir="rtl" style="font-family:Arial,sans-serif;max-width:500px;margin:auto;background:#1a1a2e;color:#fff;padding:40px;border-radius:16px;"><h1 style="text-align:center;color:#ff7043;">🔑 Infinite Notes</h1><h2 style="text-align:center;color:#e0e0e0;">رمز إعادة تعيين كلمة المرور</h2><div style="background:#3e1f0f;padding:24px;border-radius:12px;text-align:center;margin:24px 0;"><span style="font-size:36px;letter-spacing:12px;font-weight:bold;color:#ff7043;">${code}</span></div><p style="text-align:center;color:#999;">هذا الرمز صالح لمدة 10 دقائق</p></div>`;
        const result = await sendEmail(to, `رمز استعادة كلمة المرور - Infinite Notes`, html);
        if (result.ok) return jsonResponse({ success: true });
        else return jsonResponse({ success: false, error: result.data }, 500);
      } catch (err) {
        return jsonResponse({ success: false, error: err.message }, 500);
      }
    }

    return env.ASSETS.fetch(request);
  }
};
